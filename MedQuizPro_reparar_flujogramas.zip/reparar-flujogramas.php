<?php
/*
 * MedQuizPlus — encuentra los flujogramas que no están en public_html/flujogramas/ y los pone ahí.
 *
 * Uso:
 *   1. Sube este archivo a public_html (junto a index.html y algoritmos.js).
 *   2. Abre https://TU-DOMINIO/reparar-flujogramas.php  → muestra el diagnóstico (no cambia nada).
 *   3. Si hay archivos recuperables, pulsa «Reparar»: los COPIA a flujogramas/. No borra ni mueve nada.
 *   4. Al terminar la reparación, este archivo se borra solo.
 */

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
@set_time_limit(120);

$raiz = __DIR__;
$destino = $raiz . '/flujogramas';

function h($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function rel($p) { global $raiz; return ltrim(substr($p, strlen($raiz)), '/'); }

// Etiqueta naranja «✓ RESPUESTA» (por si solo queda una copia de respaldo que aún la tiene)
$conRect = '~<rect\b[^>]*fill="#f59e0b"[^>]*/>\s*<text\b[^>]*>\s*(?:<tspan\b[^>]*>\s*)?(?:✓|&#10003;|&#x2713;)?\s*RESPUESTA\s*(?:</tspan>\s*)?</text>~u';
$soloTexto = '~<text\b[^>]*>\s*(?:<tspan\b[^>]*>\s*)?(?:✓|&#10003;|&#x2713;)\s*RESPUESTA\s*(?:</tspan>\s*)?</text>~u';

echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
   . '<title>Reparar flujogramas</title><style>'
   . 'body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#f8fafc;color:#0f172a;margin:0;padding:24px 16px;line-height:1.5}'
   . 'main{max-width:900px;margin:auto}h1{color:#0f766e;font-size:22px}code{background:#f1f5f9;padding:1px 5px;border-radius:4px;font-size:12.5px;word-break:break-all}'
   . '.ok{color:#047857;font-weight:700}.err{color:#b91c1c;font-weight:700}.warn{color:#b45309;font-weight:700}'
   . 'button{background:#0f766e;color:#fff;border:0;border-radius:8px;padding:12px 20px;font-size:15px;font-weight:700;cursor:pointer}'
   . '.box{background:#fff;border:1px solid #cbd5e1;border-radius:10px;padding:14px 16px;margin:14px 0}li{margin:2px 0}</style></head><body><main>'
   . '<h1>Reparar flujogramas</h1>';

// 1. Qué SVG pide algoritmos.js
$js = @file_get_contents($raiz . '/algoritmos.js');
if ($js === false) {
    exit('<p class="err">No encontré algoritmos.js junto a este archivo. Súbelo a public_html (la misma carpeta que index.html).</p></main></body></html>');
}
preg_match_all('~imagen:\s*"flujogramas/([^"]+\.svg)"~', $js, $m);
$pedidos = array_values(array_unique($m[1]));

// 2. Todos los SVG que hay en el hosting (hasta 5 niveles), agrupados por nombre
$encontrados = [];
$it = new RecursiveIteratorIterator(
    new RecursiveCallbackFilterIterator(
        new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS),
        function ($f) { return !($f->isDir() && in_array($f->getFilename(), ['node_modules', '.git', 'cgi-bin'], true)); }
    ), RecursiveIteratorIterator::SELF_FIRST);
$it->setMaxDepth(5);
foreach ($it as $f) {
    if ($f->isFile() && strtolower($f->getExtension()) === 'svg') {
        $encontrados[$f->getFilename()][] = $f->getPathname();
    }
}

// 3. Diagnóstico
$bien = []; $recuperables = []; $perdidos = [];
foreach ($pedidos as $n) {
    if (is_file($destino . '/' . $n)) { $bien[] = $n; continue; }
    $otros = $encontrados[$n] ?? [];
    if ($otros) {
        // preferir una copia que no sea respaldo; si solo hay respaldo, usarlo y quitarle la etiqueta
        usort($otros, function ($a, $b) { return (strpos($a, 'respaldo') !== false) <=> (strpos($b, 'respaldo') !== false); });
        $recuperables[$n] = $otros[0];
    } else {
        $perdidos[] = $n;
    }
}

$carpetas = [];
foreach ($encontrados as $lista) foreach ($lista as $p) { $d = rel(dirname($p)); $carpetas[$d] = ($carpetas[$d] ?? 0) + 1; }
arsort($carpetas);

$reparar = ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirmar'] ?? '') === 'si');

if (!$reparar) {
    echo '<div class="box"><b>algoritmos.js</b> pide <b>' . count($pedidos) . '</b> flujogramas en <code>flujogramas/</code>.<br>'
       . '<span class="ok">' . count($bien) . ' están bien</span> · '
       . '<span class="warn">' . count($recuperables) . ' están en otra carpeta (se pueden recuperar)</span> · '
       . '<span class="err">' . count($perdidos) . ' no están en ningún lado</span></div>';
    echo '<div class="box"><b>Carpetas del hosting que tienen archivos SVG</b><ul>';
    if (!$carpetas) echo '<li class="err">Ninguna: no hay ningún SVG en el hosting.</li>';
    foreach ($carpetas as $d => $c) echo '<li><code>' . h($d === '' ? '(public_html)' : $d) . '/</code> — ' . $c . ' SVG</li>';
    echo '</ul>' . (is_dir($destino) ? '' : '<p class="err">La carpeta <code>flujogramas/</code> no existe en public_html.</p>') . '</div>';
    if ($recuperables) {
        echo '<form method="post"><input type="hidden" name="confirmar" value="si">'
           . '<button type="submit">Reparar: copiar ' . count($recuperables) . ' flujogramas a flujogramas/</button></form>'
           . '<details><summary>Ver de dónde se copiará cada uno</summary><ul>';
        foreach ($recuperables as $n => $p) echo '<li><code>' . h(rel($p)) . '</code> → <code>flujogramas/' . h($n) . '</code></li>';
        echo '</ul></details>';
    }
    if ($perdidos) {
        echo '<div class="box"><span class="err">No están en ningún lado (' . count($perdidos) . '):</span> copia esta lista y envíala para regenerarlos.<ul>';
        foreach ($perdidos as $n) echo '<li><code>' . h($n) . '</code></li>';
        echo '</ul></div>';
    }
    echo '<p>Esta página solo lee: no se cambió nada.</p></main></body></html>';
    exit;
}

// 4. Reparación: solo copia, nunca borra ni mueve
if (!is_dir($destino) && !@mkdir($destino, 0755)) {
    exit('<p class="err">No se pudo crear la carpeta flujogramas/. No se cambió nada.</p></main></body></html>');
}
$hechos = 0; $fallos = [];
foreach ($recuperables as $n => $p) {
    $svg = @file_get_contents($p);
    if ($svg === false) { $fallos[] = $n; continue; }
    $limpio = preg_replace($soloTexto, '', preg_replace($conRect, '', $svg));
    if ($limpio === null) $limpio = $svg;
    if (@file_put_contents($destino . '/' . $n, $limpio, LOCK_EX) === false) $fallos[] = $n; else $hechos++;
}
echo '<p class="ok">Listo: se copiaron ' . $hechos . ' flujogramas a <code>flujogramas/</code>.</p>';
if ($fallos) {
    echo '<p class="err">No se pudieron copiar:</p><ul>';
    foreach ($fallos as $n) echo '<li><code>' . h($n) . '</code></li>';
    echo '</ul>';
}
if ($perdidos) {
    echo '<p class="err">Siguen faltando ' . count($perdidos) . ' (no estaban en ningún lado):</p><ul>';
    foreach ($perdidos as $n) echo '<li><code>' . h($n) . '</code></li>';
    echo '</ul>';
}
echo '<p>No se borró ni movió ningún archivo: las carpetas de origen siguen ahí. Vuelve a abrir <code>verificar-flujogramas.html</code> para comprobar.</p>';
@unlink(__FILE__);
echo '<p>Este archivo se borró solo.</p></main></body></html>';
