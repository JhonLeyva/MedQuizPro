<?php
/*
 * MedQuizPlus — quita la etiqueta naranja "✓ RESPUESTA" de todos los flujogramas.
 *
 * Uso (una sola vez):
 *   1. Sube este archivo a public_html (junto a index.html).
 *   2. Abre https://TU-DOMINIO/quitar-etiqueta-respuesta.php
 *   3. Revisa el resumen y pulsa el botón "Quitar la etiqueta".
 *
 * Antes de modificar nada copia la carpeta a flujogramas_respaldo_AAAAMMDD-HHMMSS/.
 * Al terminar, el script se borra solo.
 */

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');

$dir = __DIR__ . '/flujogramas';

// Rectángulo naranja de la etiqueta seguido de su texto "✓ RESPUESTA".
$conRect = '~<rect\b[^>]*fill="#f59e0b"[^>]*/>\s*<text\b[^>]*>\s*(?:<tspan\b[^>]*>\s*)?(?:✓|&#10003;|&#x2713;)?\s*RESPUESTA\s*(?:</tspan>\s*)?</text>~u';
// Texto "✓ RESPUESTA" suelto, por si alguna etiqueta no tiene el rectángulo justo antes.
$soloTexto = '~<text\b[^>]*>\s*(?:<tspan\b[^>]*>\s*)?(?:✓|&#10003;|&#x2713;)\s*RESPUESTA\s*(?:</tspan>\s*)?</text>~u';

function h($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

if (!is_dir($dir)) {
    http_response_code(500);
    exit('<p>No se encontró la carpeta <code>flujogramas/</code> junto a este archivo. Súbelo a public_html.</p>');
}

$archivos = glob($dir . '/*.svg') ?: [];
$conEtiqueta = [];
foreach ($archivos as $f) {
    $svg = file_get_contents($f);
    if ($svg !== false && (preg_match($conRect, $svg) || preg_match($soloTexto, $svg))) {
        $conEtiqueta[] = $f;
    }
}

$ejecutar = ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirmar'] ?? '') === 'si');

echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
   . '<title>Quitar etiqueta RESPUESTA</title><style>'
   . 'body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#f8fafc;color:#0f172a;margin:0;padding:24px 16px;line-height:1.5}'
   . 'main{max-width:760px;margin:auto}h1{color:#0f766e;font-size:22px}code{background:#f1f5f9;padding:1px 5px;border-radius:4px;font-size:13px;word-break:break-all}'
   . '.ok{color:#047857;font-weight:700}.err{color:#b91c1c;font-weight:700}button{background:#0f766e;color:#fff;border:0;border-radius:8px;padding:12px 20px;font-size:15px;font-weight:700;cursor:pointer}'
   . 'li{margin:2px 0}</style></head><body><main><h1>Quitar la etiqueta «✓ RESPUESTA»</h1>';

if (!$ejecutar) {
    echo '<p>Flujogramas en la carpeta: <b>' . count($archivos) . '</b><br>Con la etiqueta: <b>' . count($conEtiqueta) . '</b></p>';
    if (!$conEtiqueta) {
        echo '<p class="ok">Ningún flujograma tiene la etiqueta. No hay nada que hacer.</p>';
        @unlink(__FILE__);
        echo '<p>Este archivo se borró solo.</p></main></body></html>';
        exit;
    }
    echo '<p>Se creará una copia de respaldo de la carpeta antes de modificar nada.</p>'
       . '<form method="post"><input type="hidden" name="confirmar" value="si"><button type="submit">Quitar la etiqueta de ' . count($conEtiqueta) . ' flujogramas</button></form>'
       . '<details><summary>Ver la lista</summary><ul>';
    foreach ($conEtiqueta as $f) echo '<li><code>' . h(basename($f)) . '</code></li>';
    echo '</ul></details></main></body></html>';
    exit;
}

// 1. Respaldo de toda la carpeta
$respaldo = __DIR__ . '/flujogramas_respaldo_' . date('Ymd-His');
if (!@mkdir($respaldo, 0755)) {
    exit('<p class="err">No se pudo crear la carpeta de respaldo. No se modificó nada.</p></main></body></html>');
}
foreach ($archivos as $f) {
    if (!@copy($f, $respaldo . '/' . basename($f))) {
        exit('<p class="err">Falló el respaldo de ' . h(basename($f)) . '. No se modificó nada.</p></main></body></html>');
    }
}

// 2. Limpieza
$hechos = []; $fallos = [];
foreach ($conEtiqueta as $f) {
    $svg = file_get_contents($f);
    $nuevo = preg_replace($soloTexto, '', preg_replace($conRect, '', $svg));
    if ($nuevo === null || $nuevo === $svg || @file_put_contents($f, $nuevo, LOCK_EX) === false) {
        $fallos[] = basename($f);
    } else {
        $hechos[] = basename($f);
    }
}

// 3. Comprobación final
$quedan = [];
foreach (glob($dir . '/*.svg') ?: [] as $f) {
    if (preg_match($soloTexto, (string) file_get_contents($f))) {
        $quedan[] = basename($f);
    }
}

echo '<p class="ok">Listo: se quitó la etiqueta de ' . count($hechos) . ' flujogramas.</p>';
echo '<p>Respaldo guardado en <code>' . h(basename($respaldo)) . '/</code>. Cuando confirmes que todo se ve bien, puedes borrar esa carpeta.</p>';
if ($fallos) {
    echo '<p class="err">No se pudieron modificar:</p><ul>';
    foreach ($fallos as $n) echo '<li><code>' . h($n) . '</code></li>';
    echo '</ul>';
}
if ($quedan) {
    echo '<p class="err">Todavía tienen la etiqueta:</p><ul>';
    foreach ($quedan as $n) echo '<li><code>' . h($n) . '</code></li>';
    echo '</ul>';
}
echo '<p>Recarga tu web con <b>Ctrl+F5</b> y abre cualquier flujograma para comprobarlo.</p>';

@unlink(__FILE__);
echo '<p>Este archivo se borró solo.</p></main></body></html>';
