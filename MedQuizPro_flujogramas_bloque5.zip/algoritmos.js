/* MedQuizPlus — registro de algoritmos / flujogramas del simulador.
 *
 * El botón "Ver algoritmo / Flujograma" busca aquí, en este orden:
 *   1. el id de la pregunta     (p. ej. "CAR-001")
 *   2. el nombre de la especialidad tal como viene en el banco (p. ej. "Cardiología")
 * Si no encuentra nada, el modal muestra un esquema de ejemplo.
 *
 * Cada entrada admite cualquier combinación de:
 *   titulo  — encabezado del modal
 *   imagen  — ruta a una imagen (p. ej. "algoritmos/car-001.webp"); alt — texto alternativo
 *   pasos   — flujograma dibujado en HTML: [{ texto, tipo }], tipo = inicio | decision | accion | fin
 *   nota    — perla clínica en texto
 *
 * Para añadir uno nuevo, copia el bloque de ejemplo y cambia la clave.
 */
window.MQP_ALGORITMOS = {
  "CAR-001": {
    titulo: "Infarto inferior con compromiso del ventrículo derecho",
    pasos: [
      { texto: "IAM inferior (ST↑ en DII, DIII, aVF) + hipotensión", tipo: "inicio" },
      { texto: "¿ST↑ en V4R · ingurgitación yugular · pulmones limpios?", tipo: "decision" },
      { texto: "Infarto de VD: suspender nitratos y diuréticos", tipo: "accion" },
      { texto: "Expansión de volumen con cristaloides", tipo: "accion" },
      { texto: "Reperfusión urgente (angioplastia primaria o fibrinólisis)", tipo: "fin" }
    ],
    nota: "El VD infartado depende de la precarga: todo lo que la reduce (nitratos, diuréticos, morfina) puede precipitar el shock."
  },

  /* ---------- ENAM 2020 · preguntas oficiales ---------- */

  "OFT-002": {
    titulo: "Quemadura química ocular aguda",
    imagen: "flujogramas/quemadura-quimica-ocular-aguda.svg",
    alt: "Flujograma de manejo de la quemadura química ocular aguda"
  },
  "PED-003": {
    titulo: "Dismorfología y cardiopatías en la trisomía 21",
    imagen: "flujogramas/dismorfologia-cardiopatias-trisomia-21.svg",
    alt: "Flujograma de rasgos dismórficos y cardiopatías asociadas a la trisomía 21"
  },
  "CIR-003": {
    titulo: "Trauma torácico cerrado",
    imagen: "flujogramas/trauma-toracico-cerrado.svg",
    alt: "Flujograma de manejo inicial del trauma torácico cerrado"
  },
  "INF-002": {
    titulo: "Virología: virus respiratorios",
    imagen: "flujogramas/virologia-virus-respiratorios.svg",
    alt: "Flujograma de clasificación de los virus respiratorios"
  },
  "GIN-003": {
    titulo: "Distocia en fase activa con compromiso fetal",
    imagen: "flujogramas/distocia-fase-activa-compromiso-fetal.svg",
    alt: "Flujograma de manejo de la distocia en fase activa con compromiso fetal"
  },
  "CIR-002": {
    titulo: "Abdomen agudo en pediatría",
    imagen: "flujogramas/abdomen-agudo-pediatria.svg",
    alt: "Flujograma diagnóstico del abdomen agudo en pediatría"
  },
  "PED-002": {
    titulo: "Monoartritis aguda en pediatría",
    imagen: "flujogramas/monoartritis-aguda-pediatria.svg",
    alt: "Flujograma diagnóstico de la monoartritis aguda en pediatría"
  },
  "NRL-002": {
    titulo: "Cefalea súbita: hemorragia subaracnoidea",
    imagen: "flujogramas/cefalea-subita-hemorragia-subaracnoidea.svg",
    alt: "Flujograma de estudio de la cefalea súbita y la hemorragia subaracnoidea"
  },
  "REU-002": {
    titulo: "Diagnóstico diferencial de la ictericia",
    imagen: "flujogramas/diagnostico-diferencial-ictericia.svg",
    alt: "Flujograma de diagnóstico diferencial de la ictericia y la coloración amarillenta de la piel"
  },
  "GIN-002": {
    titulo: "Rotura prematura de membranas",
    imagen: "flujogramas/rotura-prematura-membranas.svg",
    alt: "Flujograma de manejo de la rotura prematura de membranas"
  },

  /* ---------- ENAM 2020 · preguntas 22 a 31 ---------- */

  "PED-004": {
    titulo: "Membrana hialina (SDR neonatal)",
    imagen: "flujogramas/membrana-hialina-sdra-neonatal.svg",
    alt: "Flujograma diagnóstico de la enfermedad de membrana hialina o síndrome de dificultad respiratoria neonatal"
  },
  "HEM-002": {
    titulo: "Anemia ferropénica: perfil de hierro",
    imagen: "flujogramas/anemia-ferropenica-perfil-hierro.svg",
    alt: "Flujograma de interpretación del perfil de hierro en la anemia ferropénica"
  },
  "NEF-002": {
    titulo: "Hiperpotasemia: manejo de urgencia",
    imagen: "flujogramas/hiperpotasemia-manejo-urgencia.svg",
    alt: "Flujograma de manejo de urgencia de la hiperpotasemia"
  },
  "GIN-004": {
    titulo: "Hipertensión gestacional: diagnóstico",
    imagen: "flujogramas/hipertension-gestacional-diagnostico.svg",
    alt: "Flujograma diagnóstico de la hipertensión gestacional"
  },
  "SP-002": {
    titulo: "Parto humanizado con enfoque intercultural",
    imagen: "flujogramas/parto-humanizado-intercultural.svg",
    alt: "Flujograma de atención del parto humanizado con enfoque intercultural"
  },
  "GIN-005": {
    titulo: "Preeclampsia con criterios de severidad",
    imagen: "flujogramas/preeclampsia-con-criterios-severidad.svg",
    alt: "Flujograma de criterios de severidad de la preeclampsia"
  },
  "NRL-003": {
    titulo: "Hematoma epidural de fosa posterior",
    imagen: "flujogramas/hematoma-epidural-fosa-posterior.svg",
    alt: "Flujograma de manejo del hematoma epidural de fosa posterior"
  },
  "REU-003": {
    titulo: "Artritis reumatoide: anticuerpos anti-CCP",
    imagen: "flujogramas/artritis-reumatoide-anticuerpos-anti-ccp.svg",
    alt: "Flujograma diagnóstico de la artritis reumatoide con anticuerpos anti-CCP"
  },
  "INF-003": {
    titulo: "Mononucleosis infecciosa (virus de Epstein-Barr)",
    imagen: "flujogramas/mononucleosis-infecciosa-veb.svg",
    alt: "Flujograma diagnóstico de la mononucleosis infecciosa por virus de Epstein-Barr"
  },
  "PED-005": {
    titulo: "Rubéola: diagnóstico exantemático",
    imagen: "flujogramas/rubeola-diagnostico-exantematico.svg",
    alt: "Flujograma de diagnóstico diferencial de exantemas y rubéola"
  },

  /* ---------- ENAM 2020 · preguntas 32 a 51 ---------- */

  "END-002": {
    titulo: "Hipotiroidismo subclínico: diagnóstico",
    imagen: "flujogramas/hipotiroidismo-subclinico-diagnostico.svg",
    alt: "Flujograma diagnóstico del hipotiroidismo subclínico"
  },
  "GIN-006": {
    titulo: "Mastitis puerperal: manejo",
    imagen: "flujogramas/mastitis-puerperal-manejo.svg",
    alt: "Flujograma de manejo de la mastitis puerperal"
  },
  "GAS-002": {
    titulo: "Diarrea disentérica: antibioticoterapia",
    imagen: "flujogramas/diarrea-disenterica-antibioticoterapia.svg",
    alt: "Flujograma de manejo antibiótico de la diarrea disentérica"
  },
  "SP-003": {
    titulo: "Consejería nutricional en la gestante",
    imagen: "flujogramas/consejeria-nutricional-gestante.svg",
    alt: "Flujograma de consejería nutricional en la gestante"
  },
  "PED-006": {
    titulo: "Diarrea invasiva por Campylobacter en el lactante",
    imagen: "flujogramas/diarrea-invasiva-campylobacter-lactante.svg",
    alt: "Flujograma de la diarrea invasiva por Campylobacter en el lactante"
  },
  "GIN-007": {
    titulo: "Pielonefritis aguda en la gestación",
    imagen: "flujogramas/pielonefritis-aguda-gestacion.svg",
    alt: "Flujograma de manejo de la pielonefritis aguda en la gestación"
  },
  "OFT-003": {
    titulo: "Glaucoma congénito: goniotomía",
    imagen: "flujogramas/glaucoma-congenito-goniotomia.svg",
    alt: "Flujograma diagnóstico y terapéutico del glaucoma congénito"
  },
  "INF-004": {
    titulo: "Chancro luético: sífilis primaria",
    imagen: "flujogramas/chancro-luetico-sifilis-primaria.svg",
    alt: "Flujograma diagnóstico del chancro luético en la sífilis primaria"
  },
  "END-003": {
    titulo: "Tormenta tiroidea: crisis tirotóxica",
    imagen: "flujogramas/tormenta-tiroidea-crisis-tirotoxica.svg",
    alt: "Flujograma de manejo de la tormenta tiroidea"
  },
  "GAS-003": {
    titulo: "Pancreatitis crónica: bloqueo celíaco",
    imagen: "flujogramas/pancreatitis-cronica-bloqueo-celiaco.svg",
    alt: "Flujograma de manejo del dolor en la pancreatitis crónica con bloqueo celíaco"
  },
  "PED-007": {
    titulo: "Vacunación neonatal: BCG y HvB",
    imagen: "flujogramas/vacunacion-neonatal-bcg-hvb.svg",
    alt: "Flujograma de vacunación neonatal con BCG y hepatitis B"
  },
  "PSI-002": {
    titulo: "Trastorno de pánico: crisis de ansiedad",
    imagen: "flujogramas/trastorno-de-panico-crisis-ansiedad.svg",
    alt: "Flujograma diagnóstico del trastorno de pánico"
  },
  "PED-008": {
    titulo: "Obstrucción neonatal: tapón meconial",
    imagen: "flujogramas/obstruccion-neonatal-tapon-meconial.svg",
    alt: "Flujograma diagnóstico de la obstrucción intestinal neonatal por tapón meconial"
  },
  "NEF-003": {
    titulo: "Pielonefritis aguda: diagnóstico clínico",
    imagen: "flujogramas/pielonefritis-aguda-diagnostico-clinico.svg",
    alt: "Flujograma de diagnóstico clínico de la pielonefritis aguda"
  },
  "END-004": {
    titulo: "Tolerancia oral a la glucosa y secreción de insulina",
    imagen: "flujogramas/tolerancia-oral-glucosa-secrecion-insulina.svg",
    alt: "Flujograma de la prueba de tolerancia oral a la glucosa para valorar la secreción de insulina"
  },
  "PED-009": {
    titulo: "Otitis media aguda en el lactante",
    imagen: "flujogramas/otitis-media-aguda-lactante.svg",
    alt: "Flujograma diagnóstico de la otitis media aguda en el lactante"
  },
  "NEU-002": {
    titulo: "Tromboembolismo pulmonar: alteplase",
    imagen: "flujogramas/tromboembolismo-pulmonar-alteplase.svg",
    alt: "Flujograma de manejo del tromboembolismo pulmonar masivo con alteplase"
  },
  "SP-004": {
    titulo: "Vulneración del principio de autonomía: confidencialidad",
    imagen: "flujogramas/vulneracion-principio-autonomia-confidencialidad.svg",
    alt: "Flujograma sobre la vulneración de la autonomía y la confidencialidad del paciente"
  },
  "PED-010": {
    titulo: "Bronquitis aguda pediátrica",
    imagen: "flujogramas/bronquitis-aguda-pediatrica.svg",
    alt: "Flujograma diagnóstico de la bronquitis aguda en pediatría"
  },
  "REU-004": {
    titulo: "Urticaria aguda y angioedema",
    imagen: "flujogramas/urticaria-aguda-angioedema.svg",
    alt: "Flujograma de manejo de la urticaria aguda con angioedema"
  },

  /* ---------- ENAM 2020 · preguntas 52 a 71 ---------- */

  "SP-005": {
    titulo: "Prevención del embarazo adolescente: educación",
    imagen: "flujogramas/prevencion-embarazo-adolescente-educacion.svg",
    alt: "Flujograma de intervención educativa para la prevención del embarazo adolescente"
  },
  "GAS-004": {
    titulo: "Enfermedad por reflujo gastroesofágico (ERGE)",
    imagen: "flujogramas/enfermedad-reflujo-gastroesofagico-erge.svg",
    alt: "Flujograma diagnóstico y terapéutico de la enfermedad por reflujo gastroesofágico"
  },
  "INF-005": {
    titulo: "Neumonía por Pneumocystis jirovecii en VIH",
    imagen: "flujogramas/neumonia-pneumocystis-jirovecii-vih.svg",
    alt: "Flujograma diagnóstico de la neumonía por Pneumocystis jirovecii en el paciente con VIH"
  },
  "CIR-004": {
    titulo: "Neumotórax a tensión: toracocentesis",
    imagen: "flujogramas/neumotorax-a-tension-toracocentesis.svg",
    alt: "Flujograma de manejo del neumotórax a tensión con descompresión por toracocentesis"
  },
  "GIN-008": {
    titulo: "Maduración cervical en el embarazo prolongado",
    imagen: "flujogramas/maduracion-cervical-embarazo-prolongado.svg",
    alt: "Flujograma de maduración cervical e inducción en el embarazo prolongado"
  },
  "SP-006": {
    titulo: "Conflicto de intereses en bioética",
    imagen: "flujogramas/conflicto-de-intereses-bioetica.svg",
    alt: "Flujograma sobre el conflicto de intereses en bioética e integridad científica"
  },
  "GIN-009": {
    titulo: "Embarazo ectópico: ecografía transvaginal",
    imagen: "flujogramas/embarazo-ectopico-ecografia-transvaginal.svg",
    alt: "Flujograma de estudio del embarazo ectópico con ecografía transvaginal"
  },
  "REU-005": {
    titulo: "Acarosis (escabiosis) en el lactante: permetrina",
    imagen: "flujogramas/acarosis-escabiosis-lactante-permetrina.svg",
    alt: "Flujograma diagnóstico y terapéutico de la escabiosis en el lactante con permetrina"
  },
  "GAS-005": {
    titulo: "Screening de cáncer colorrectal: colonoscopia",
    imagen: "flujogramas/screening-cancer-colorrectal-colonoscopia.svg",
    alt: "Flujograma de tamizaje del cáncer colorrectal con colonoscopia"
  },
  "CIR-005": {
    titulo: "Quemaduras: irrigación con agua a temperatura ambiente",
    imagen: "flujogramas/quemaduras-irrigacion-agua-ambiente.svg",
    alt: "Flujograma de manejo inicial de las quemaduras con irrigación de agua a temperatura ambiente"
  },
  "CAR-004": {
    titulo: "Hipertensión arterial grado 2: tratamiento",
    imagen: "flujogramas/hipertension-arterial-grado-2-tratamiento.svg",
    alt: "Flujograma de tratamiento de la hipertensión arterial grado 2 con daño de órgano blanco"
  },
  "NRL-004": {
    titulo: "Déficit de vitamina B12: degeneración cordonal",
    imagen: "flujogramas/deficit-vitamina-b12-degeneracion-cordonal.svg",
    alt: "Flujograma del déficit de vitamina B12 con degeneración combinada subaguda de cordones medulares"
  },
  "GIN-010": {
    titulo: "Parto podálico: referencia quirúrgica",
    imagen: "flujogramas/parto-podalico-referencia-quirurgica.svg",
    alt: "Flujograma de manejo y referencia del parto en presentación podálica"
  },
  "CAR-005": {
    titulo: "Transposición de grandes arterias (TGA)",
    imagen: "flujogramas/transposicion-de-grandes-arterias-tga.svg",
    alt: "Flujograma diagnóstico de la transposición de grandes arterias"
  },
  "SP-007": {
    titulo: "Diseño cuasi experimental en epidemiología",
    imagen: "flujogramas/diseno-cuasi-experimental-epidemiologia.svg",
    alt: "Flujograma de clasificación de diseños de investigación y el diseño cuasi experimental"
  },
  "PSI-003": {
    titulo: "Hiperventilación: alcalosis respiratoria y bolsa de papel",
    imagen: "flujogramas/hiperventilacion-alcalosis-respiratoria-bolsa.svg",
    alt: "Flujograma de manejo de la alcalosis respiratoria por hiperventilación con reinhalación en bolsa"
  },
  "TRA-002": {
    titulo: "Displasia del desarrollo de la cadera: ecografía",
    imagen: "flujogramas/displasia-desarrollo-cadera-ecografia.svg",
    alt: "Flujograma diagnóstico de la displasia del desarrollo de la cadera con ecografía"
  },
  "PED-011": {
    titulo: "Hipoglicemia neonatal en hijo de madre diabética",
    imagen: "flujogramas/hipoglicemia-neonatal-hijo-madre-diabetica.svg",
    alt: "Flujograma de la hipoglicemia neonatal en el recién nacido macrosómico hijo de madre diabética"
  },
  "PED-012": {
    titulo: "Desnutrición aguda: emaciación y antropometría",
    imagen: "flujogramas/desnutricion-aguda-emaciacion-antropometria.svg",
    alt: "Flujograma de clasificación antropométrica de la desnutrición aguda"
  },
  "SP-008": {
    titulo: "Plan Nacional contra la Anemia: equipo de salud",
    imagen: "flujogramas/plan-nacional-anemia-equipo-salud.svg",
    alt: "Flujograma de responsabilidades del equipo de salud en el Plan Nacional contra la Anemia"
  },

  /* ---------- ENAM 2020 · bloque 2 (preguntas 72 a 122) ---------- */

  "CAR-006": {
    titulo: "Infarto agudo de miocardio inferior",
    imagen: "flujogramas/infarto-agudo-miocardio-inferior.svg",
    alt: "Flujograma diagnóstico del infarto agudo de miocardio de cara inferior"
  },
  "CB-002": {
    titulo: "Mialgias por estatinas y gemfibrozilo",
    imagen: "flujogramas/mialgias-estatinas-gemfibrozilo.svg",
    alt: "Flujograma de la miopatía por la asociación de estatinas y gemfibrozilo"
  },
  "CB-003": {
    titulo: "Intoxicación por organofosforados: atropina",
    imagen: "flujogramas/intoxicacion-organofosforados-atropina.svg",
    alt: "Flujograma de manejo de la intoxicación por organofosforados con atropina"
  },
  "CIR-006": {
    titulo: "Telangiectasias: escleroterapia",
    imagen: "flujogramas/telangiectasias-escleroterapia.svg",
    alt: "Flujograma de manejo de las telangiectasias con escleroterapia"
  },
  "CIR-007": {
    titulo: "Regla de los nueves en quemaduras",
    imagen: "flujogramas/regla-de-los-nueves-quemaduras.svg",
    alt: "Flujograma de cálculo de la superficie corporal quemada con la regla de los nueves"
  },
  "CIR-008": {
    titulo: "Injuria inhalatoria: intubación precoz",
    imagen: "flujogramas/injuria-inhalatoria-intubacion-precoz.svg",
    alt: "Flujograma de manejo de la injuria inhalatoria con intubación precoz"
  },
  "END-005": {
    titulo: "Hipotiroidismo primario: levotiroxina",
    imagen: "flujogramas/hipotiroidismo-primario-levotiroxina.svg",
    alt: "Flujograma diagnóstico y terapéutico del hipotiroidismo primario con levotiroxina"
  },
  "GIN-011": {
    titulo: "Embarazo postérmino: cesárea de emergencia",
    imagen: "flujogramas/embarazo-postermino-cesarea-emergencia.svg",
    alt: "Flujograma de manejo del embarazo postérmino con compromiso fetal y cesárea de emergencia"
  },
  "GIN-012": {
    titulo: "Maduración pulmonar fetal: betametasona",
    imagen: "flujogramas/maduracion-pulmonar-fetal-betametasona.svg",
    alt: "Flujograma de maduración pulmonar fetal con betametasona en el parto pretérmino"
  },
  "GIN-013": {
    titulo: "Enfermedad pélvica inflamatoria: signo de Frenkel",
    imagen: "flujogramas/enfermedad-pelvica-inflamatoria-frenkel.svg",
    alt: "Flujograma diagnóstico de la enfermedad pélvica inflamatoria"
  },
  "HEM-003": {
    titulo: "Anemia megaloblástica por resección del íleon",
    imagen: "flujogramas/anemia-megaloblastica-reseccion-ileon.svg",
    alt: "Flujograma de la anemia megaloblástica por malabsorción de vitamina B12 tras resección ileal"
  },
  "NEF-004": {
    titulo: "Glomerulonefritis postestreptocócica: C3",
    imagen: "flujogramas/glomerulonefritis-postestreptococica-c3.svg",
    alt: "Flujograma diagnóstico de la glomerulonefritis postestreptocócica con complemento C3 bajo"
  },
  "PED-013": {
    titulo: "Sepsis neonatal temprana: ampicilina + amikacina",
    imagen: "flujogramas/sepsis-neonatal-temprana-ampicilina-amikacina.svg",
    alt: "Flujograma de manejo de la sepsis neonatal temprana con ampicilina y amikacina"
  },
  "PED-014": {
    titulo: "Varicela: diagnóstico clínico",
    imagen: "flujogramas/varicela-diagnostico-clinico.svg",
    alt: "Flujograma de diagnóstico clínico de la varicela"
  },
  "PED-015": {
    titulo: "Estenosis hipertrófica de píloro: rehidratación",
    imagen: "flujogramas/estenosis-hipertrofica-piloro-rehidratacion.svg",
    alt: "Flujograma de manejo inicial de la estenosis hipertrófica de píloro con rehidratación"
  },
  "PED-016": {
    titulo: "Laringotraqueítis (crup): estridor",
    imagen: "flujogramas/laringotraqueitis-crup-estridor.svg",
    alt: "Flujograma diagnóstico y terapéutico de la laringotraqueítis o crup"
  },
  "PED-017": {
    titulo: "Otitis media aguda: amoxicilina",
    imagen: "flujogramas/otitis-media-aguda-amoxicilina.svg",
    alt: "Flujograma de tratamiento de la otitis media aguda con amoxicilina"
  },
  "REU-006": {
    titulo: "Foliculitis estafilocócica: dicloxacilina",
    imagen: "flujogramas/foliculitis-estafilococica-dicloxacilina.svg",
    alt: "Flujograma de manejo de la foliculitis estafilocócica con dicloxacilina"
  },
  "SP-009": {
    titulo: "Menor que rechaza tratamiento: aviso a la fiscalía",
    imagen: "flujogramas/rechazo-tratamiento-menor-fiscalia.svg",
    alt: "Flujograma de actuación ante el rechazo de tratamiento en un menor de edad"
  },
  "SP-010": {
    titulo: "Prevención secundaria: diabetes y obesidad",
    imagen: "flujogramas/prevencion-secundaria-diabetes-obesidad.svg",
    alt: "Flujograma de los niveles de prevención aplicados a la diabetes y la obesidad"
  },
  "SP-011": {
    titulo: "Captación precoz en el control prenatal",
    imagen: "flujogramas/captacion-precoz-control-prenatal.svg",
    alt: "Flujograma de captación precoz y seguimiento de la gestante en el control prenatal"
  },
  "SP-012": {
    titulo: "Población asegurada de EsSalud",
    imagen: "flujogramas/poblacion-asegurada-essalud.svg",
    alt: "Flujograma de la población usuaria del Seguro Social de Salud (EsSalud)"
  },
  "SP-013": {
    titulo: "Definición epidemiológica de brote",
    imagen: "flujogramas/definicion-epidemiologica-brote.svg",
    alt: "Flujograma de la definición epidemiológica de brote en vigilancia"
  },
  "TRA-003": {
    titulo: "Sección del tendón palmar menor",
    imagen: "flujogramas/seccion-tendon-palmar-menor.svg",
    alt: "Flujograma de evaluación de la sección del tendón palmar menor"
  },
  "TRA-004": {
    titulo: "Síndrome compartimental: fasciotomía",
    imagen: "flujogramas/sindrome-compartimental-fasciotomia.svg",
    alt: "Flujograma de manejo del síndrome compartimental con fasciotomía"
  },

  /* ---------- ENAM 2020 · bloque 3 (preguntas 123 a 172) ---------- */

  "INF-008": {
    titulo: "Neumonía asociada al ventilador: meropenem + vancomicina",
    imagen: "flujogramas/neumonia-asociada-ventilador-meropenem-vancomicina.svg",
    alt: "Flujograma de tratamiento empírico de la neumonía asociada a ventilación mecánica"
  },
  "TRA-005": {
    titulo: "Escoliosis estructural: test de Adams",
    imagen: "flujogramas/escoliosis-estructural-test-adams.svg",
    alt: "Flujograma diagnóstico de la escoliosis estructural con el test de Adams"
  },
  "PED-022": {
    titulo: "Shock hipovolémico por deshidratación neonatal",
    imagen: "flujogramas/shock-hipovolemico-deshidratacion-neonatal.svg",
    alt: "Flujograma de manejo del shock hipovolémico por deshidratación en el neonato"
  },
  "GIN-016": {
    titulo: "Gestación anembrionada (huevo huero)",
    imagen: "flujogramas/gestacion-anembrionada-huevo-huero.svg",
    alt: "Flujograma diagnóstico ecográfico de la gestación anembrionada"
  },
  "PED-023": {
    titulo: "Tos ferina: reacción leucemoide",
    imagen: "flujogramas/tos-ferina-reaccion-leucemoide.svg",
    alt: "Flujograma de factores pronósticos de la tos ferina con reacción leucemoide"
  },
  "PED-024": {
    titulo: "Intususcepción (invaginación intestinal) en pediatría",
    imagen: "flujogramas/intususcepcion-invaginacion-intestinal-pediatria.svg",
    alt: "Flujograma diagnóstico de la intususcepción intestinal en el lactante"
  },
  "INF-009": {
    titulo: "Meningitis tuberculosa: ADA en LCR",
    imagen: "flujogramas/meningitis-tuberculosa-ada-lcr.svg",
    alt: "Flujograma diagnóstico de la meningitis tuberculosa con ADA en líquido cefalorraquídeo"
  },
  "PED-025": {
    titulo: "Intoxicación por organofosforados en pediatría",
    imagen: "flujogramas/intoxicacion-organofosforados-pediatria.svg",
    alt: "Flujograma de la intoxicación por organofosforados en el niño"
  },
  "SP-017": {
    titulo: "Determinantes sociales: saneamiento y desnutrición",
    imagen: "flujogramas/determinantes-sociales-saneamiento-desnutricion.svg",
    alt: "Flujograma de determinantes sociales de la salud, saneamiento básico y desnutrición"
  },
  "CB-004": {
    titulo: "Intoxicación por metanol: acidosis y amaurosis",
    imagen: "flujogramas/intoxicacion-metanol-acidosis-amaurosis.svg",
    alt: "Flujograma de la intoxicación por metanol con acidosis metabólica y amaurosis"
  },
  "PED-026": {
    titulo: "Crisis convulsiva: diazepam",
    imagen: "flujogramas/convulsion-febril-status-diazepam.svg",
    alt: "Flujograma de manejo inmediato de la crisis convulsiva pediátrica con diazepam"
  },
  "NEF-008": {
    titulo: "Cólico renoureteral: UroTAC",
    imagen: "flujogramas/colico-renoureteral-urotac-urotem.svg",
    alt: "Flujograma diagnóstico del cólico renoureteral con UroTAC"
  },
  "PED-027": {
    titulo: "Neumonía bacteriana: consolidación alveolar",
    imagen: "flujogramas/neumonia-bacteriana-consolidacion-alveolar.svg",
    alt: "Flujograma de la neumonía bacteriana pediátrica con consolidación alveolar"
  },
  "GIN-017": {
    titulo: "Candidiasis vulvovaginal",
    imagen: "flujogramas/candidiasis-vulvovaginal-micotica.svg",
    alt: "Flujograma diagnóstico de la vaginitis micótica o candidiasis vulvovaginal"
  },
  "GIN-018": {
    titulo: "Atonía uterina: palpación bimanual",
    imagen: "flujogramas/atonia-uterina-palpacion-bimanual.svg",
    alt: "Flujograma de evaluación de la hemorragia posparto por atonía uterina"
  },
  "REU-007": {
    titulo: "Vasculitis leucocitoclástica: púrpura palpable",
    imagen: "flujogramas/vasculitis-leucocitoclastica-purpura-palpable.svg",
    alt: "Flujograma diagnóstico de la vasculitis con púrpura palpable"
  },
  "GIN-019": {
    titulo: "VIH intraparto: cesárea de emergencia",
    imagen: "flujogramas/vih-intraparto-cesarea-emergencia.svg",
    alt: "Flujograma de manejo del parto en la gestante con VIH diagnosticado intraparto"
  },
  "CB-005": {
    titulo: "Anafilaxia: mastocitos e hipersensibilidad tipo I",
    imagen: "flujogramas/anafilaxia-mastocitos-hipersensibilidad-tipo-i.svg",
    alt: "Flujograma de la anafilaxia mediada por IgE y la degranulación de mastocitos"
  },
  "NEU-004": {
    titulo: "Pleuresía tuberculosa: ADA y exudado",
    imagen: "flujogramas/pleuresia-tuberculosa-ada-exudado.svg",
    alt: "Flujograma diagnóstico de la pleuresía tuberculosa con exudado linfocitario y ADA elevada"
  },
  "PED-028": {
    titulo: "Púrpura trombocitopénica inmune postvacunal",
    imagen: "flujogramas/purpura-trombocitopenica-inmune-postvacunal.svg",
    alt: "Flujograma diagnóstico de la púrpura trombocitopénica inmune posterior a vacunación"
  },
  "PED-029": {
    titulo: "Urocultivo falso negativo por antibióticos",
    imagen: "flujogramas/urocultivo-falso-negativo-antibioticos.svg",
    alt: "Flujograma de causas de urocultivo falso negativo"
  },
  "PED-030": {
    titulo: "Rinitis alérgica y asma atópica",
    imagen: "flujogramas/rinitis-alergica-asma-atopica.svg",
    alt: "Flujograma diagnóstico de la rinitis alérgica en el paciente atópico"
  },
  "NRL-005": {
    titulo: "Accidente isquémico transitorio (AIT)",
    imagen: "flujogramas/accidente-isquemico-transitorio-ait.svg",
    alt: "Flujograma diagnóstico del accidente isquémico transitorio"
  },
  "NRL-006": {
    titulo: "Hematoma epidural: arteria meníngea media",
    imagen: "flujogramas/hematoma-epidural-arteria-meningea-media.svg",
    alt: "Flujograma diagnóstico del hematoma epidural por lesión de la arteria meníngea media"
  },
  "PSI-006": {
    titulo: "Trastorno de personalidad límite (borderline)",
    imagen: "flujogramas/trastorno-personalidad-limite-borderline.svg",
    alt: "Flujograma diagnóstico del trastorno límite de la personalidad"
  },
  "CIR-013": {
    titulo: "Hernia crural (femoral) complicada",
    imagen: "flujogramas/hernia-crural-femoral-complicada.svg",
    alt: "Flujograma diagnóstico de la hernia crural complicada"
  },
  "SP-018": {
    titulo: "Tuberculosis: control ambiental y ventilación",
    imagen: "flujogramas/tuberculosis-control-ambiental-ventilacion.svg",
    alt: "Flujograma de medidas de control ambiental de la tuberculosis en establecimientos de salud"
  },
  "CB-006": {
    titulo: "Anfetaminas: vasoconstricción y resistencia periférica",
    imagen: "flujogramas/anfetaminas-resistencia-periferica-vasoconstriccion.svg",
    alt: "Flujograma del mecanismo hipertensivo de las anfetaminas por aumento de la resistencia periférica"
  },
  "GIN-020": {
    titulo: "Hipodinamia uterina: estimulación con oxitocina",
    imagen: "flujogramas/hipodinamia-uterina-estimulacion-oxitocina.svg",
    alt: "Flujograma de manejo de la hipodinamia uterina con oxitocina"
  },
  "GIN-021": {
    titulo: "Síndrome de ovario poliquístico: factor ovárico",
    imagen: "flujogramas/sindrome-ovario-poliquistico-factor-ovarico.svg",
    alt: "Flujograma de la amenorrea anovulatoria por síndrome de ovario poliquístico"
  },
  "PED-031": {
    titulo: "Saturnismo: intoxicación crónica por plomo",
    imagen: "flujogramas/saturnismo-intoxicacion-cronica-plomo.svg",
    alt: "Flujograma diagnóstico de la intoxicación crónica por plomo en el niño"
  },
  "GIN-022": {
    titulo: "Hipertensión severa en la gestación: referencia",
    imagen: "flujogramas/hipertension-severa-gestacion-referencia.svg",
    alt: "Flujograma de referencia de la gestante con hipertensión severa"
  },
  "GIN-023": {
    titulo: "Prolapso genital con úlceras: estrógenos tópicos",
    imagen: "flujogramas/prolapso-genital-ulceras-estrogenos-topicos.svg",
    alt: "Flujograma de preparación del prolapso genital ulcerado con estrógenos tópicos"
  },
  "OFT-005": {
    titulo: "Conjuntivitis alérgica: prurito bilateral",
    imagen: "flujogramas/conjuntivitis-alergica-prurito-bilateral.svg",
    alt: "Flujograma diagnóstico de la conjuntivitis alérgica"
  },
  "SP-019": {
    titulo: "Dengue: control vectorial del Aedes",
    imagen: "flujogramas/dengue-control-vectorial-aedes.svg",
    alt: "Flujograma de control vectorial del Aedes aegypti ante un caso importado de dengue"
  },
  "CAR-009": {
    titulo: "Paro cardiorrespiratorio: compresiones torácicas",
    imagen: "flujogramas/paro-cardiorrespiratorio-compresiones-toracicas.svg",
    alt: "Flujograma de reanimación cardiopulmonar con inicio de compresiones torácicas"
  },
  "REU-008": {
    titulo: "Tinea capitis: dermatofitosis del cuero cabelludo",
    imagen: "flujogramas/tinea-capitis-dermatofitosis-cuero-cabelludo.svg",
    alt: "Flujograma diagnóstico de la tiña de la cabeza"
  },
  "NRL-007": {
    titulo: "Síndrome de cola de caballo tras anestesia raquídea",
    imagen: "flujogramas/sindrome-cola-caballo-anestesia-raquidea.svg",
    alt: "Flujograma del síndrome de cola de caballo como complicación de la anestesia raquídea"
  },
  "NEF-009": {
    titulo: "Torsión testicular: reflejo cremastérico",
    imagen: "flujogramas/torsion-testicular-reflejo-cremasterico.svg",
    alt: "Flujograma diagnóstico del escroto agudo y la torsión testicular"
  },
  "GIN-024": {
    titulo: "Desprendimiento prematuro de placenta: hipertonía",
    imagen: "flujogramas/desprendimiento-prematuro-placenta-hipertonia.svg",
    alt: "Flujograma diagnóstico del desprendimiento prematuro de placenta"
  },
  "GIN-025": {
    titulo: "Metrorragia posmenopáusica: biopsia de endometrio",
    imagen: "flujogramas/metrorragia-posmenopausica-biopsia-endometrio.svg",
    alt: "Flujograma de estudio de la metrorragia posmenopáusica con biopsia de endometrio"
  },
  "CAR-010": {
    titulo: "Endocarditis infecciosa: ecocardiografía transesofágica",
    imagen: "flujogramas/endocarditis-infecciosa-ecocardiografia-transesofagica.svg",
    alt: "Flujograma diagnóstico de la endocarditis infecciosa con ecocardiografía transesofágica"
  },
  "GIN-026": {
    titulo: "Altura uterina: 12 semanas en la sínfisis del pubis",
    imagen: "flujogramas/altura-uterina-12-semanas-sinfisis-pubis.svg",
    alt: "Flujograma de estimación de la edad gestacional por altura uterina"
  },
  "PED-032": {
    titulo: "Hepatitis A: coluria en el escolar",
    imagen: "flujogramas/hepatitis-a-coluria-escolar.svg",
    alt: "Flujograma diagnóstico de la hepatitis A en el escolar"
  },
  "GIN-027": {
    titulo: "Amenaza de parto pretérmino",
    imagen: "flujogramas/amenaza-parto-pretermino-cervix-cerrado.svg",
    alt: "Flujograma diagnóstico de la amenaza de parto pretérmino"
  },
  "INF-010": {
    titulo: "Dengue con signos de alarma",
    imagen: "flujogramas/dengue-con-signos-alarma-madre-de-dios.svg",
    alt: "Flujograma diagnóstico del dengue con signos de alarma"
  },
  "CAR-011": {
    titulo: "Insuficiencia cardíaca aguda: furosemida",
    imagen: "flujogramas/insuficiencia-cardiaca-aguda-furosemida-diureticos.svg",
    alt: "Flujograma de manejo de la insuficiencia cardíaca aguda congestiva con diuréticos"
  },
  "NEU-005": {
    titulo: "Enfermedad pulmonar intersticial: crepitantes",
    imagen: "flujogramas/enfermedad-pulmonar-intersticial-crepitantes.svg",
    alt: "Flujograma diagnóstico de la enfermedad pulmonar intersticial difusa"
  },
  "GIN-028": {
    titulo: "Metrorragia del primer trimestre: ecografía transvaginal",
    imagen: "flujogramas/metrorragia-primer-trimestre-ecografia-transvaginal.svg",
    alt: "Flujograma de estudio del sangrado del primer trimestre con ecografía transvaginal"
  },

  /* ---------- ENAM 2020 · bloque 2 (preguntas pendientes) ---------- */

  "CAR-007": {
    titulo: "Estenosis mitral reumática y fibrilación auricular",
    imagen: "flujogramas/estenosis-mitral-fibrilacion-auricular-warfarina.svg",
    alt: "Flujograma: estenosis mitral reumática y fibrilación auricular"
  },
  "CAR-008": {
    titulo: "Miocardiopatía chagásica y arritmias",
    imagen: "flujogramas/miocardiopatia-chagasica-taquicardia-ventricular-amiodarona.svg",
    alt: "Flujograma: miocardiopatía chagásica y arritmias"
  },
  "CIR-009": {
    titulo: "Isquemia arterial aguda: clasificación de Rutherford",
    imagen: "flujogramas/isquemia-arterial-aguda-rutherford-amputacion.svg",
    alt: "Flujograma: isquemia arterial aguda: clasificación de Rutherford"
  },
  "CIR-010": {
    titulo: "Complicaciones de la hernioplastia inguinal",
    imagen: "flujogramas/orquitis-isquemica-post-hernioplastia.svg",
    alt: "Flujograma: complicaciones de la hernioplastia inguinal"
  },
  "CIR-011": {
    titulo: "Trauma abdominal cerrado",
    imagen: "flujogramas/trauma-abdominal-cerrado-fast.svg",
    alt: "Flujograma: trauma abdominal cerrado"
  },
  "CIR-012": {
    titulo: "Fístula perianal",
    imagen: "flujogramas/fistula-perianal-goodsall.svg",
    alt: "Flujograma: fístula perianal"
  },
  "GAS-006": {
    titulo: "Hemorragia digestiva alta por úlcera péptica",
    imagen: "flujogramas/hemorragia-digestiva-alta-ulcera-peptica.svg",
    alt: "Flujograma: hemorragia digestiva alta por úlcera péptica"
  },
  "GAS-007": {
    titulo: "Hemorragia por várices esofágicas",
    imagen: "flujogramas/hemorragia-variceal-hipertension-portal.svg",
    alt: "Flujograma: hemorragia por várices esofágicas"
  },
  "GIN-014": {
    titulo: "Hemorragia de la primera mitad del embarazo",
    imagen: "flujogramas/amenaza-de-aborto-primer-trimestre.svg",
    alt: "Flujograma: hemorragia de la primera mitad del embarazo"
  },
  "GIN-015": {
    titulo: "Miomatosis uterina submucosa",
    imagen: "flujogramas/mioma-submucoso-miomectomia-histeroscopica.svg",
    alt: "Flujograma: miomatosis uterina submucosa"
  },
  "INF-006": {
    titulo: "Leishmaniasis cutánea",
    imagen: "flujogramas/leishmaniasis-cutanea-antimonial-pentavalente.svg",
    alt: "Flujograma: leishmaniasis cutánea"
  },
  "INF-007": {
    titulo: "Malaria: diagnóstico y gravedad",
    imagen: "flujogramas/malaria-diagnostico-gravedad-amazonia.svg",
    alt: "Flujograma: malaria: diagnóstico y gravedad"
  },
  "NEF-005": {
    titulo: "Síndrome nefrótico vs. nefrítico",
    imagen: "flujogramas/sindrome-nefrotico-pediatrico-cambios-minimos.svg",
    alt: "Flujograma: síndrome nefrótico vs. nefrítico"
  },
  "NEF-006": {
    titulo: "Rabdomiólisis por aplastamiento",
    imagen: "flujogramas/rabdomiolisis-aplastamiento-lesion-renal.svg",
    alt: "Flujograma: rabdomiólisis por aplastamiento"
  },
  "NEF-007": {
    titulo: "Síndrome nefrótico del adulto",
    imagen: "flujogramas/sindrome-nefrotico-adulto-proteinuria.svg",
    alt: "Flujograma: síndrome nefrótico del adulto"
  },
  "NEU-003": {
    titulo: "Asma: escalonamiento del tratamiento",
    imagen: "flujogramas/asma-escalonamiento-corticoide-inhalado.svg",
    alt: "Flujograma: asma: escalonamiento del tratamiento"
  },
  "OFT-004": {
    titulo: "Epistaxis posterior",
    imagen: "flujogramas/epistaxis-posterior-taponamiento.svg",
    alt: "Flujograma: epistaxis posterior"
  },
  "PED-018": {
    titulo: "Giardiasis",
    imagen: "flujogramas/giardiasis-diarrea-cronica-escolar.svg",
    alt: "Flujograma: giardiasis"
  },
  "PED-019": {
    titulo: "Atresia intestinal",
    imagen: "flujogramas/atresia-intestinal-prematuros.svg",
    alt: "Flujograma: atresia intestinal"
  },
  "PED-020": {
    titulo: "Meningitis neonatal",
    imagen: "flujogramas/meningitis-neonatal-sepsis-temprana.svg",
    alt: "Flujograma: meningitis neonatal"
  },
  "PED-021": {
    titulo: "Conjuntivitis neonatal",
    imagen: "flujogramas/conjuntivitis-neonatal-gonococica.svg",
    alt: "Flujograma: conjuntivitis neonatal"
  },
  "PSI-004": {
    titulo: "Intoxicación por benzodiacepinas",
    imagen: "flujogramas/intoxicacion-benzodiacepinas-flumazenilo.svg",
    alt: "Flujograma: intoxicación por benzodiacepinas"
  },
  "PSI-005": {
    titulo: "Conducta suicida: clasificación",
    imagen: "flujogramas/gesto-suicida-conducta-suicida.svg",
    alt: "Flujograma: conducta suicida: clasificación"
  },
  "SP-014": {
    titulo: "Coinfección TB-VIH",
    imagen: "flujogramas/coinfeccion-tb-vih-terapia-preventiva.svg",
    alt: "Flujograma: coinfección TB-VIH"
  },
  "SP-015": {
    titulo: "Veracidad en la relación médico-paciente",
    imagen: "flujogramas/veracidad-informacion-adolescente-bioetica.svg",
    alt: "Flujograma: veracidad en la relación médico-paciente"
  },
  "SP-016": {
    titulo: "Violencia contra la mujer",
    imagen: "flujogramas/violencia-familiar-ley-30364.svg",
    alt: "Flujograma: violencia contra la mujer"
  },

  /* ---------- Casos de práctica (preguntas tipo) ---------- */

  "CAR-002": {
    titulo: "Fibrilación auricular no valvular",
    imagen: "flujogramas/fibrilacion-auricular-no-valvular-anticoagulacion.svg",
    alt: "Flujograma: fibrilación auricular no valvular"
  },
  "CAR-003": {
    titulo: "Soplos sistólicos: estenosis aórtica",
    imagen: "flujogramas/estenosis-aortica-severa-sincope.svg",
    alt: "Flujograma: soplos sistólicos: estenosis aórtica"
  },
  "CB-001": {
    titulo: "Fenilcetonuria",
    imagen: "flujogramas/fenilcetonuria-fenilalanina-hidroxilasa.svg",
    alt: "Flujograma: fenilcetonuria"
  },
  "CIR-001": {
    titulo: "Apendicitis aguda",
    imagen: "flujogramas/apendicitis-aguda-apendicectomia.svg",
    alt: "Flujograma: apendicitis aguda"
  },
  "END-001": {
    titulo: "Cetoacidosis diabética",
    imagen: "flujogramas/cetoacidosis-diabetica-hidratacion.svg",
    alt: "Flujograma: cetoacidosis diabética"
  },
  "GAS-001": {
    titulo: "Sangrado variceal: tratamiento inicial",
    imagen: "flujogramas/hemorragia-variceal-vasoactivos.svg",
    alt: "Flujograma: sangrado variceal: tratamiento inicial"
  },
  "GIN-001": {
    titulo: "Hemorragia posparto por atonía uterina",
    imagen: "flujogramas/hemorragia-posparto-atonia-oxitocina.svg",
    alt: "Flujograma: hemorragia posparto por atonía uterina"
  },
  "HEM-001": {
    titulo: "Anemia microcítica",
    imagen: "flujogramas/anemia-microcitica-ferritina.svg",
    alt: "Flujograma: anemia microcítica"
  },
  "INF-001": {
    titulo: "Malaria por Plasmodium vivax",
    imagen: "flujogramas/malaria-vivax-cloroquina-primaquina.svg",
    alt: "Flujograma: malaria por Plasmodium vivax"
  },
  "NEF-001": {
    titulo: "Hiperpotasemia con cambios en el ECG",
    imagen: "flujogramas/hiperpotasemia-gluconato-de-calcio.svg",
    alt: "Flujograma: hiperpotasemia con cambios en el ECG"
  },
  "NEU-001": {
    titulo: "Derrame pleural: enfoque diagnóstico",
    imagen: "flujogramas/derrame-pleural-enfoque-tuberculosis.svg",
    alt: "Flujograma: derrame pleural, enfoque diagnóstico"
  },
  "NRL-001": {
    titulo: "Ictus agudo: primer examen",
    imagen: "flujogramas/acv-agudo-tomografia-sin-contraste.svg",
    alt: "Flujograma: ictus agudo: primer examen"
  },
  "OFT-001": {
    titulo: "Glaucoma agudo de ángulo cerrado",
    imagen: "flujogramas/glaucoma-agudo-angulo-cerrado.svg",
    alt: "Flujograma: glaucoma agudo de ángulo cerrado"
  },
  "PED-001": {
    titulo: "Ictericia neonatal",
    imagen: "flujogramas/ictericia-neonatal-incompatibilidad-abo.svg",
    alt: "Flujograma: ictericia neonatal"
  },
  "PSI-001": {
    titulo: "Episodio depresivo mayor",
    imagen: "flujogramas/depresion-mayor-isrs.svg",
    alt: "Flujograma: episodio depresivo mayor"
  },
  "REU-001": {
    titulo: "Artritis por cristales",
    imagen: "flujogramas/gota-cristales-urato-monosodico.svg",
    alt: "Flujograma: artritis por cristales"
  },
  "SP-001": {
    titulo: "Validez de una prueba diagnóstica",
    imagen: "flujogramas/sensibilidad-especificidad-tabla-2x2.svg",
    alt: "Flujograma: validez de una prueba diagnóstica"
  },
  "TRA-001": {
    titulo: "Fractura de escafoides",
    imagen: "flujogramas/fractura-escafoides-tabaquera-anatomica.svg",
    alt: "Flujograma: fractura de escafoides"
  },

  /* ---------- ENAM 2020 · bloque 2 (preguntas 174-259 del banco PDF) ---------- */

  "CIR-014": {
    titulo: "Fisura anal",
    imagen: "flujogramas/fisura-anal-esfinter-hipertonico.svg",
    alt: "Flujograma: Fisura anal"
  },
  "NEU-006": {
    titulo: "Tuberculosis pulmonar: diagnóstico",
    imagen: "flujogramas/tuberculosis-pulmonar-baciloscopia-diagnostico.svg",
    alt: "Flujograma: Tuberculosis pulmonar: diagnóstico"
  },
  "INF-011": {
    titulo: "Uretritis gonocócica",
    imagen: "flujogramas/uretritis-gonococica-ceftriaxona.svg",
    alt: "Flujograma: Uretritis gonocócica"
  },
  "REU-009": {
    titulo: "Dermatitis atópica del lactante",
    imagen: "flujogramas/dermatitis-atopica-lactante-diferencial.svg",
    alt: "Flujograma: Dermatitis atópica del lactante"
  },
  "GIN-029": {
    titulo: "Trabajo de parto prolongado",
    imagen: "flujogramas/trabajo-parto-prolongado-cesarea.svg",
    alt: "Flujograma: Trabajo de parto prolongado"
  },
  "CIR-015": {
    titulo: "Plastrón apendicular",
    imagen: "flujogramas/plastron-apendicular-manejo-conservador.svg",
    alt: "Flujograma: Plastrón apendicular"
  },
  "END-006": {
    titulo: "Hipotiroidismo primario",
    imagen: "flujogramas/hipotiroidismo-mixedema-tsh-levotiroxina.svg",
    alt: "Flujograma: Hipotiroidismo primario"
  },
  "CB-007": {
    titulo: "Beta oxidación de ácidos grasos",
    imagen: "flujogramas/deficit-mcad-beta-oxidacion.svg",
    alt: "Flujograma: Beta oxidación de ácidos grasos"
  },
  "NRL-008": {
    titulo: "Enfermedad de Parkinson",
    imagen: "flujogramas/enfermedad-parkinson-levodopa.svg",
    alt: "Flujograma: Enfermedad de Parkinson"
  },
  "PSI-007": {
    titulo: "Duelo y riesgo suicida en adolescentes",
    imagen: "flujogramas/duelo-adolescente-riesgo-suicida.svg",
    alt: "Flujograma: Duelo y riesgo suicida en adolescentes"
  },
  "PSI-008": {
    titulo: "Trastorno obsesivo-compulsivo",
    imagen: "flujogramas/trastorno-obsesivo-compulsivo-contaminacion.svg",
    alt: "Flujograma: Trastorno obsesivo-compulsivo"
  },
  "PSI-009": {
    titulo: "Esquizofrenia paranoide",
    imagen: "flujogramas/esquizofrenia-paranoide-diferencial.svg",
    alt: "Flujograma: Esquizofrenia paranoide"
  },
  "PSI-010": {
    titulo: "Episodio depresivo mayor",
    imagen: "flujogramas/episodio-depresivo-mayor-adolescente.svg",
    alt: "Flujograma: Episodio depresivo mayor"
  },
  "PSI-011": {
    titulo: "Ataque de pánico",
    imagen: "flujogramas/ataque-de-panico-evolucion.svg",
    alt: "Flujograma: Ataque de pánico"
  },
  "SP-020": {
    titulo: "Objeción de conciencia",
    imagen: "flujogramas/objecion-de-conciencia-derivacion.svg",
    alt: "Flujograma: Objeción de conciencia"
  },
  "PED-033": {
    titulo: "Intoxicación por organofosforados",
    imagen: "flujogramas/organofosforados-atropina-pediatria.svg",
    alt: "Flujograma: Intoxicación por organofosforados"
  },
  "NEF-010": {
    titulo: "Anemia en enfermedad renal crónica",
    imagen: "flujogramas/anemia-erc-hierro-eritropoyetina.svg",
    alt: "Flujograma: Anemia en enfermedad renal crónica"
  },
  "NEF-011": {
    titulo: "Rabdomiólisis y lesión renal aguda",
    imagen: "flujogramas/rabdomiolisis-aplastamiento-lra.svg",
    alt: "Flujograma: Rabdomiólisis y lesión renal aguda"
  },
  "CB-008": {
    titulo: "Farmacología del paracetamol",
    imagen: "flujogramas/paracetamol-farmacologia-cox.svg",
    alt: "Flujograma: Farmacología del paracetamol"
  },
  "NEF-012": {
    titulo: "Nefropatía diabética",
    imagen: "flujogramas/nefropatia-diabetica-ieca.svg",
    alt: "Flujograma: Nefropatía diabética"
  },
  "CIR-016": {
    titulo: "Politraumatizado en shock: manejo inicial",
    imagen: "flujogramas/politraumatizado-shock-xabcde.svg",
    alt: "Flujograma: Politraumatizado en shock: manejo inicial"
  },
  "GIN-030": {
    titulo: "Presentación podálica",
    imagen: "flujogramas/presentacion-podalica-cesarea.svg",
    alt: "Flujograma: Presentación podálica"
  },
  "GIN-031": {
    titulo: "Endometritis puerperal",
    imagen: "flujogramas/endometritis-puerperal-fiebre-posparto.svg",
    alt: "Flujograma: Endometritis puerperal"
  },
  "CB-009": {
    titulo: "Embriología: implantación",
    imagen: "flujogramas/implantacion-blastocisto-embriologia.svg",
    alt: "Flujograma: Embriología: implantación"
  },
  "GIN-032": {
    titulo: "Corioamnionitis",
    imagen: "flujogramas/corioamnionitis-fiebre-intraparto.svg",
    alt: "Flujograma: Corioamnionitis"
  },
  "GIN-033": {
    titulo: "Desprendimiento prematuro de placenta",
    imagen: "flujogramas/desprendimiento-placenta-hemorragia-tercer-trimestre.svg",
    alt: "Flujograma: Desprendimiento prematuro de placenta"
  },
  "GIN-034": {
    titulo: "Placenta previa",
    imagen: "flujogramas/placenta-previa-hospitalizacion-ecografia.svg",
    alt: "Flujograma: Placenta previa"
  },
  "CIR-017": {
    titulo: "Quemaduras: manejo prehospitalario",
    imagen: "flujogramas/quemaduras-manejo-prehospitalario.svg",
    alt: "Flujograma: Quemaduras: manejo prehospitalario"
  },
  "CAR-012": {
    titulo: "QT prolongado por fármacos",
    imagen: "flujogramas/qt-prolongado-cloroquina.svg",
    alt: "Flujograma: QT prolongado por fármacos"
  },
  "CB-010": {
    titulo: "Anafilaxia e hipersensibilidad",
    imagen: "flujogramas/anafilaxia-picadura-adrenalina.svg",
    alt: "Flujograma: Anafilaxia e hipersensibilidad"
  },
  "NEF-013": {
    titulo: "Intoxicación por metanol y acidosis metabólica",
    imagen: "flujogramas/intoxicacion-metanol-licor-adulterado.svg",
    alt: "Flujograma: Intoxicación por metanol y acidosis metabólica"
  },
  "TRA-006": {
    titulo: "Trauma cervical por latigazo",
    imagen: "flujogramas/trauma-cervical-latigazo-impacto-posterior.svg",
    alt: "Flujograma: Trauma cervical por latigazo"
  },
  "GIN-035": {
    titulo: "Tamizaje de diabetes gestacional",
    imagen: "flujogramas/tamizaje-diabetes-gestacional-ptog.svg",
    alt: "Flujograma: Tamizaje de diabetes gestacional"
  },
  "INF-012": {
    titulo: "Tuberculosis y lactancia materna",
    imagen: "flujogramas/tuberculosis-lactancia-materna.svg",
    alt: "Flujograma: Tuberculosis y lactancia materna"
  },
  "PED-034": {
    titulo: "Displasia broncopulmonar",
    imagen: "flujogramas/displasia-broncopulmonar-prematuro.svg",
    alt: "Flujograma: Displasia broncopulmonar"
  },
  "GIN-036": {
    titulo: "Inmunoprofilaxis anti-D",
    imagen: "flujogramas/inmunoprofilaxis-anti-d-puerpera.svg",
    alt: "Flujograma: Inmunoprofilaxis anti-D"
  },
  "GAS-008": {
    titulo: "Encefalopatía hepática",
    imagen: "flujogramas/encefalopatia-hepatica-west-haven.svg",
    alt: "Flujograma: Encefalopatía hepática"
  },
  "CAR-013": {
    titulo: "Reanimación cardiopulmonar básica",
    imagen: "flujogramas/rcp-basica-adulto-compresiones.svg",
    alt: "Flujograma: Reanimación cardiopulmonar básica"
  },
  "GIN-037": {
    titulo: "Gestante Rh negativa: Coombs indirecto",
    imagen: "flujogramas/gestante-rh-negativo-coombs-indirecto.svg",
    alt: "Flujograma: Gestante Rh negativa: Coombs indirecto"
  },
  "GIN-038": {
    titulo: "Restricción del crecimiento intrauterino",
    imagen: "flujogramas/restriccion-crecimiento-intrauterino-doppler.svg",
    alt: "Flujograma: Restricción del crecimiento intrauterino"
  },
  "SP-021": {
    titulo: "Salud ocupacional: aislamiento por COVID-19",
    imagen: "flujogramas/trabajador-covid-asintomatico-aislamiento.svg",
    alt: "Flujograma: Salud ocupacional: aislamiento por COVID-19"
  },
  "INF-013": {
    titulo: "VIH y vía del parto",
    imagen: "flujogramas/vih-gestante-carga-viral-via-parto.svg",
    alt: "Flujograma: VIH y vía del parto"
  },
  "GIN-039": {
    titulo: "Enfermedad inflamatoria pélvica",
    imagen: "flujogramas/enfermedad-inflamatoria-pelvica-instrumentacion.svg",
    alt: "Flujograma: Enfermedad inflamatoria pélvica"
  },
  "HEM-004": {
    titulo: "Anemia perniciosa",
    imagen: "flujogramas/anemia-perniciosa-factor-intrinseco.svg",
    alt: "Flujograma: Anemia perniciosa"
  },
  "GIN-040": {
    titulo: "Mola hidatiforme",
    imagen: "flujogramas/mola-hidatiforme-diferencial.svg",
    alt: "Flujograma: Mola hidatiforme"
  },
  "GIN-041": {
    titulo: "Aborto inevitable",
    imagen: "flujogramas/aborto-inevitable-clasificacion.svg",
    alt: "Flujograma: Aborto inevitable"
  },
  "PED-035": {
    titulo: "Intususcepción intestinal",
    imagen: "flujogramas/intususcepcion-reduccion-enema.svg",
    alt: "Flujograma: Intususcepción intestinal"
  },
  "CAR-014": {
    titulo: "Trombosis venosa profunda",
    imagen: "flujogramas/trombosis-venosa-profunda-eco-duplex.svg",
    alt: "Flujograma: Trombosis venosa profunda"
  },
  "NEF-014": {
    titulo: "Hidrocele",
    imagen: "flujogramas/hidrocele-transiluminacion-escroto.svg",
    alt: "Flujograma: Hidrocele"
  },
  "NEF-015": {
    titulo: "Litiasis coraliforme de estruvita",
    imagen: "flujogramas/litiasis-coraliforme-estruvita.svg",
    alt: "Flujograma: Litiasis coraliforme de estruvita"
  },

  /* ---------- Bloque 3 (preguntas 262-360 del banco PDF): tema general + ruta del caso ---------- */

  "CIR-018": {
    titulo: "Heridas traumáticas: manejo antibiótico",
    imagen: "flujogramas/heridas-traumaticas-antibioticoterapia.svg",
    alt: "Flujograma: Heridas traumáticas: manejo antibiótico"
  },
  "TRA-007": {
    titulo: "Fracturas expuestas: Gustilo-Anderson",
    imagen: "flujogramas/fractura-expuesta-gustilo-anderson.svg",
    alt: "Flujograma: Fracturas expuestas: Gustilo-Anderson"
  },
  "CIR-019": {
    titulo: "Infecciones necrotizantes de partes blandas",
    imagen: "flujogramas/infecciones-necrotizantes-gangrena-gaseosa.svg",
    alt: "Flujograma: Infecciones necrotizantes de partes blandas"
  },
  "OFT-006": {
    titulo: "Epistaxis: manejo escalonado",
    imagen: "flujogramas/epistaxis-manejo-escalonado.svg",
    alt: "Flujograma: Epistaxis: manejo escalonado"
  },
  "CB-011": {
    titulo: "Anestésicos locales: clasificación y duración",
    imagen: "flujogramas/anestesicos-locales-clasificacion-duracion.svg",
    alt: "Flujograma: Anestésicos locales: clasificación y duración"
  },
  "CIR-020": {
    titulo: "Trauma torácico con amenaza vital",
    imagen: "flujogramas/trauma-toracico-neumotorax-tension.svg",
    alt: "Flujograma: Trauma torácico con amenaza vital"
  },
  "NEF-016": {
    titulo: "Masa escrotal en el adulto",
    imagen: "flujogramas/masa-escrotal-cancer-testicular.svg",
    alt: "Flujograma: Masa escrotal en el adulto"
  },
  "CIR-021": {
    titulo: "Complicaciones de la hernioplastia inguinal",
    imagen: "flujogramas/complicaciones-hernioplastia-inguinal.svg",
    alt: "Flujograma: Complicaciones de la hernioplastia inguinal"
  },
  "NRL-009": {
    titulo: "Traumatismo craneal: lesiones según su localización",
    imagen: "flujogramas/tec-lesiones-fractura-base-craneo.svg",
    alt: "Flujograma: Traumatismo craneal: lesiones según su localización"
  },
  "INF-014": {
    titulo: "Fiebre tifoidea: evolución y complicaciones",
    imagen: "flujogramas/fiebre-tifoidea-complicaciones.svg",
    alt: "Flujograma: Fiebre tifoidea: evolución y complicaciones"
  },
  "CAR-015": {
    titulo: "Dolor torácico con troponina elevada",
    imagen: "flujogramas/dolor-toracico-troponina-takotsubo.svg",
    alt: "Flujograma: Dolor torácico con troponina elevada"
  },
  "CAR-016": {
    titulo: "Síndrome aórtico agudo",
    imagen: "flujogramas/sindrome-aortico-agudo-diseccion.svg",
    alt: "Flujograma: Síndrome aórtico agudo"
  },
  "NEU-007": {
    titulo: "Insuficiencia respiratoria aguda: soporte",
    imagen: "flujogramas/insuficiencia-respiratoria-soporte-ventilatorio.svg",
    alt: "Flujograma: Insuficiencia respiratoria aguda: soporte"
  },
  "CAR-017": {
    titulo: "Pericarditis: enfoque etiológico",
    imagen: "flujogramas/pericarditis-enfoque-etiologico-tuberculosa.svg",
    alt: "Flujograma: Pericarditis: enfoque etiológico"
  },
  "INF-015": {
    titulo: "Úlcera genital y sífilis",
    imagen: "flujogramas/ulcera-genital-sifilis-histopatologia.svg",
    alt: "Flujograma: Úlcera genital y sífilis"
  },
  "GAS-009": {
    titulo: "Colitis ulcerosa y sus complicaciones",
    imagen: "flujogramas/colitis-ulcerosa-cancer-colorrectal.svg",
    alt: "Flujograma: Colitis ulcerosa y sus complicaciones"
  },
  "GAS-010": {
    titulo: "Enfermedad de Crohn: complicaciones",
    imagen: "flujogramas/enfermedad-crohn-fistulas.svg",
    alt: "Flujograma: Enfermedad de Crohn: complicaciones"
  },
  "GAS-011": {
    titulo: "Diarrea crónica: enfoque por tipo",
    imagen: "flujogramas/diarrea-cronica-malabsorcion-esteatorrea.svg",
    alt: "Flujograma: Diarrea crónica: enfoque por tipo"
  },
  "CIR-022": {
    titulo: "Isquemia mesentérica aguda",
    imagen: "flujogramas/isquemia-mesenterica-aguda-etiologia.svg",
    alt: "Flujograma: Isquemia mesentérica aguda"
  },
  "CAR-018": {
    titulo: "Muerte súbita en el joven deportista",
    imagen: "flujogramas/muerte-subita-joven-miocardiopatia-hipertrofica.svg",
    alt: "Flujograma: Muerte súbita en el joven deportista"
  },
  "NEU-008": {
    titulo: "Derrame pleural: criterios de Light",
    imagen: "flujogramas/derrame-pleural-trasudado-light.svg",
    alt: "Flujograma: Derrame pleural: criterios de Light"
  },
  "INF-016": {
    titulo: "Enfermedades metaxénicas y sus vectores",
    imagen: "flujogramas/metaxenicas-vectores-peru-dengue.svg",
    alt: "Flujograma: Enfermedades metaxénicas y sus vectores"
  },
  "SP-022": {
    titulo: "Adecuación del esfuerzo terapéutico",
    imagen: "flujogramas/adecuacion-esfuerzo-terapeutico-paliativos.svg",
    alt: "Flujograma: Adecuación del esfuerzo terapéutico"
  },
  "SP-023": {
    titulo: "Certificado de defunción y muerte violenta",
    imagen: "flujogramas/certificado-defuncion-muerte-violenta.svg",
    alt: "Flujograma: Certificado de defunción y muerte violenta"
  },
  "END-007": {
    titulo: "Tirotoxicosis: enfoque diagnóstico",
    imagen: "flujogramas/tirotoxicosis-enfoque-tormenta-tiroidea.svg",
    alt: "Flujograma: Tirotoxicosis: enfoque diagnóstico"
  },
  "PED-036": {
    titulo: "ITU en el niño: estudio por imágenes",
    imagen: "flujogramas/itu-pediatrica-imagenes-reflujo.svg",
    alt: "Flujograma: ITU en el niño: estudio por imágenes"
  },
  "PED-037": {
    titulo: "Neumonía en menores de 5 años",
    imagen: "flujogramas/neumonia-menor-5-anos-clasificacion.svg",
    alt: "Flujograma: Neumonía en menores de 5 años"
  },
  "PED-038": {
    titulo: "Reanimación neonatal",
    imagen: "flujogramas/reanimacion-neonatal-algoritmo.svg",
    alt: "Flujograma: Reanimación neonatal"
  },
  "SP-024": {
    titulo: "Diseños de estudios epidemiológicos",
    imagen: "flujogramas/disenos-estudio-epidemiologico-ecologico.svg",
    alt: "Flujograma: Diseños de estudios epidemiológicos"
  },
  "OFT-007": {
    titulo: "Rinitis: clasificación",
    imagen: "flujogramas/rinitis-clasificacion-vasomotora.svg",
    alt: "Flujograma: Rinitis: clasificación"
  },
  "SP-025": {
    titulo: "Niveles de prevención",
    imagen: "flujogramas/niveles-prevencion-tuberculosis.svg",
    alt: "Flujograma: Niveles de prevención"
  },
  "SP-026": {
    titulo: "Peste: formas clínicas y contactos",
    imagen: "flujogramas/peste-formas-clinicas-contactos.svg",
    alt: "Flujograma: Peste: formas clínicas y contactos"
  },
  "PED-040": {
    titulo: "Sepsis neonatal: temprana y tardía",
    imagen: "flujogramas/sepsis-neonatal-temprana-tardia.svg",
    alt: "Flujograma: Sepsis neonatal: temprana y tardía"
  },
  "PED-041": {
    titulo: "Insuficiencia cardiaca en el lactante",
    imagen: "flujogramas/insuficiencia-cardiaca-lactante-furosemida.svg",
    alt: "Flujograma: Insuficiencia cardiaca en el lactante"
  },
  "SP-027": {
    titulo: "Calidad de atención: dimensiones SERVQUAL",
    imagen: "flujogramas/calidad-servqual-dimensiones.svg",
    alt: "Flujograma: Calidad de atención: dimensiones SERVQUAL"
  },
  "REU-010": {
    titulo: "Dermatosis pruriginosas del lactante",
    imagen: "flujogramas/dermatitis-atopica-lactante-diferencial-prurito.svg",
    alt: "Flujograma: Dermatosis pruriginosas del lactante"
  },
  "PED-042": {
    titulo: "Neumonía en el niño: típica, atípica y viral",
    imagen: "flujogramas/neumonia-nino-tipica-atipica-viral.svg",
    alt: "Flujograma: Neumonía en el niño: típica, atípica y viral"
  },
  "TRA-008": {
    titulo: "Tumores óseos en niños y adolescentes",
    imagen: "flujogramas/tumores-oseos-osteosarcoma.svg",
    alt: "Flujograma: Tumores óseos en niños y adolescentes"
  },
  "NRL-010": {
    titulo: "Debilidad aguda de miembros inferiores",
    imagen: "flujogramas/debilidad-aguda-mielitis-transversa.svg",
    alt: "Flujograma: Debilidad aguda de miembros inferiores"
  },
  "PED-043": {
    titulo: "Síndrome nefrítico en el niño",
    imagen: "flujogramas/sindrome-nefritico-glomerulonefritis-postestreptococica.svg",
    alt: "Flujograma: Síndrome nefrítico en el niño"
  },
  "INF-017": {
    titulo: "Síndrome de secreción uretral",
    imagen: "flujogramas/secrecion-uretral-manejo-sindromico.svg",
    alt: "Flujograma: Síndrome de secreción uretral"
  },
  "INF-018": {
    titulo: "Meningitis bacteriana según la edad",
    imagen: "flujogramas/meningitis-bacteriana-edad-meningococo.svg",
    alt: "Flujograma: Meningitis bacteriana según la edad"
  },
  "GAS-012": {
    titulo: "Hepatitis viral aguda: serología",
    imagen: "flujogramas/hepatitis-viral-aguda-serologia.svg",
    alt: "Flujograma: Hepatitis viral aguda: serología"
  },
  "NEF-017": {
    titulo: "Escroto agudo en el niño",
    imagen: "flujogramas/escroto-agudo-torsion-testicular.svg",
    alt: "Flujograma: Escroto agudo en el niño"
  },
  "PED-044": {
    titulo: "Lesiones del plexo braquial en el RN",
    imagen: "flujogramas/plexo-braquial-erb-duchenne.svg",
    alt: "Flujograma: Lesiones del plexo braquial en el RN"
  },
  "PED-045": {
    titulo: "Convulsiones neonatales",
    imagen: "flujogramas/convulsiones-neonatales-tipos.svg",
    alt: "Flujograma: Convulsiones neonatales"
  },
  "PED-046": {
    titulo: "Ictericia neonatal indirecta",
    imagen: "flujogramas/ictericia-neonatal-indirecta-policitemia.svg",
    alt: "Flujograma: Ictericia neonatal indirecta"
  },
  "NRL-011": {
    titulo: "TEC: indicaciones de TC",
    imagen: "flujogramas/tec-indicaciones-tomografia.svg",
    alt: "Flujograma: TEC: indicaciones de TC"
  },
  "HEM-005": {
    titulo: "Anemia microcítica: enfoque diagnóstico",
    imagen: "flujogramas/anemia-microcitica-enfoque-diagnostico.svg",
    alt: "Flujograma: Anemia microcítica: enfoque diagnóstico"
  },
  "PED-039": {
    titulo: "Edema en el niño: síndrome nefrótico y nefrítico",
    imagen: "flujogramas/edema-renal-nino-nefrotico-nefritico.svg",
    alt: "Flujograma: Edema en el niño: síndrome nefrótico y nefrítico"
  },
  /* ── Bloque 4: 100 flujogramas (diseños árbol, radial, fases, termómetro y tarjetas) ── */
  "TRA-009": {
    titulo: "Lesiones nerviosas en fracturas del miembro superior",
    imagen: "flujogramas/fractura-humero-lesion-nervio-radial.svg",
    alt: "Flujograma: Lesiones nerviosas en fracturas del miembro superior"
  },
  "CIR-023": {
    titulo: "Obstrucción intestinal: diagnóstico y causa",
    imagen: "flujogramas/obstruccion-intestinal-bridas.svg",
    alt: "Flujograma: Obstrucción intestinal: diagnóstico y causa"
  },
  "SP-028": {
    titulo: "Principios de la bioética",
    imagen: "flujogramas/principios-bioetica-justicia.svg",
    alt: "Flujograma: Principios de la bioética"
  },
  "SP-029": {
    titulo: "Diseños de investigación",
    imagen: "flujogramas/disenos-investigacion-transversal.svg",
    alt: "Flujograma: Diseños de investigación"
  },
  "CIR-024": {
    titulo: "Hernias de la región inguinal",
    imagen: "flujogramas/hernias-ingle-directa.svg",
    alt: "Flujograma: Hernias de la región inguinal"
  },
  "SP-030": {
    titulo: "COVID-19: definiciones operativas",
    imagen: "flujogramas/covid-definicion-contacto-directo.svg",
    alt: "Flujograma: COVID-19: definiciones operativas"
  },
  "CIR-025": {
    titulo: "Shock séptico: control del foco",
    imagen: "flujogramas/shock-septico-control-foco.svg",
    alt: "Flujograma: Shock séptico: control del foco"
  },
  "CAR-019": {
    titulo: "Paro cardiorrespiratorio: primeros minutos",
    imagen: "flujogramas/paro-cardiorrespiratorio-rcp-monitor.svg",
    alt: "Flujograma: Paro cardiorrespiratorio: primeros minutos"
  },
  "CB-012": {
    titulo: "Citocromo P450 e interacciones",
    imagen: "flujogramas/citocromo-p450-interacciones.svg",
    alt: "Flujograma: Citocromo P450 e interacciones"
  },
  "GIN-042": {
    titulo: "Hemorragias de la segunda mitad del embarazo",
    imagen: "flujogramas/hemorragia-tercer-trimestre-dpp.svg",
    alt: "Flujograma: Hemorragias de la segunda mitad del embarazo"
  },
  "GIN-043": {
    titulo: "Dolor abdominal agudo en la gestante",
    imagen: "flujogramas/dolor-abdominal-gestante-apendicitis.svg",
    alt: "Flujograma: Dolor abdominal agudo en la gestante"
  },
  "GIN-044": {
    titulo: "Parto podálico: tiempos y maniobras",
    imagen: "flujogramas/parto-podalico-maniobras.svg",
    alt: "Flujograma: Parto podálico: tiempos y maniobras"
  },
  "CB-013": {
    titulo: "Surfactante pulmonar",
    imagen: "flujogramas/surfactante-pulmonar-lecitina.svg",
    alt: "Flujograma: Surfactante pulmonar"
  },
  "GIN-045": {
    titulo: "Candidiasis vulvovaginal",
    imagen: "flujogramas/candidiasis-vulvovaginal-recurrente.svg",
    alt: "Flujograma: Candidiasis vulvovaginal"
  },
  "REU-011": {
    titulo: "Dolor musculoesquelético difuso",
    imagen: "flujogramas/fibromialgia-diagnostico-diferencial.svg",
    alt: "Flujograma: Dolor musculoesquelético difuso"
  },
  "NRL-012": {
    titulo: "Déficit de tiamina: Wernicke y Korsakoff",
    imagen: "flujogramas/deficit-tiamina-wernicke-korsakoff.svg",
    alt: "Flujograma: Déficit de tiamina: Wernicke y Korsakoff"
  },
  "INF-019": {
    titulo: "Infecciones del SNC en el paciente con VIH",
    imagen: "flujogramas/vih-infecciones-snc-criptococo.svg",
    alt: "Flujograma: Infecciones del SNC en el paciente con VIH"
  },
  "CIR-026": {
    titulo: "Mordeduras: manejo inicial",
    imagen: "flujogramas/mordeduras-humana-animal-manejo.svg",
    alt: "Flujograma: Mordeduras: manejo inicial"
  },
  "SP-031": {
    titulo: "Decisiones al final de la vida",
    imagen: "flujogramas/final-vida-obstinacion-terapeutica.svg",
    alt: "Flujograma: Decisiones al final de la vida"
  },
  "SP-032": {
    titulo: "Violencia contra la mujer: conducta del médico",
    imagen: "flujogramas/violencia-mujer-denuncia-ley-30364.svg",
    alt: "Flujograma: Violencia contra la mujer: conducta del médico"
  },
  "REU-012": {
    titulo: "Urticaria: clasificación y tratamiento",
    imagen: "flujogramas/urticaria-antihistaminico-escalera.svg",
    alt: "Flujograma: Urticaria: clasificación y tratamiento"
  },
  "NEF-018": {
    titulo: "Síndrome nefrótico del adulto: biopsia renal",
    imagen: "flujogramas/sindrome-nefrotico-amiloidosis-aa.svg",
    alt: "Flujograma: Síndrome nefrótico del adulto: biopsia renal"
  },
  "NEF-019": {
    titulo: "Indicaciones de diálisis urgente",
    imagen: "flujogramas/dialisis-urgente-pericarditis-uremica.svg",
    alt: "Flujograma: Indicaciones de diálisis urgente"
  },
  "NEF-020": {
    titulo: "Lesión renal aguda intrínseca",
    imagen: "flujogramas/lesion-renal-intrinseca-nefritis-intersticial.svg",
    alt: "Flujograma: Lesión renal aguda intrínseca"
  },
  "REU-013": {
    titulo: "Escabiosis: diagnóstico y tratamiento",
    imagen: "flujogramas/escabiosis-lactante-permetrina.svg",
    alt: "Flujograma: Escabiosis: diagnóstico y tratamiento"
  },
  "CIR-027": {
    titulo: "Quemadura con lesión por inhalación",
    imagen: "flujogramas/quemadura-lesion-inhalatoria-oxigeno.svg",
    alt: "Flujograma: Quemadura con lesión por inhalación"
  },
  "PED-047": {
    titulo: "Vómitos en el neonato y el lactante",
    imagen: "flujogramas/vomitos-neonato-estenosis-piloro.svg",
    alt: "Flujograma: Vómitos en el neonato y el lactante"
  },
  "PED-048": {
    titulo: "Sibilancias en el niño",
    imagen: "flujogramas/sibilancias-nino-asma.svg",
    alt: "Flujograma: Sibilancias en el niño"
  },
  "PED-049": {
    titulo: "Neumonía en el niño",
    imagen: "flujogramas/neumonia-nino-hospitalizado-ceftriaxona.svg",
    alt: "Flujograma: Neumonía en el niño"
  },
  "CB-014": {
    titulo: "Aterosclerosis: capa afectada y evolución",
    imagen: "flujogramas/aterosclerosis-capa-intima.svg",
    alt: "Flujograma: Aterosclerosis: capa afectada y evolución"
  },
  "CIR-028": {
    titulo: "Enfermedad arterial periférica",
    imagen: "flujogramas/enfermedad-arterial-periferica-bypass.svg",
    alt: "Flujograma: Enfermedad arterial periférica"
  },
  "PED-050": {
    titulo: "Dificultad respiratoria quirúrgica del recién nacido",
    imagen: "flujogramas/hernia-diafragmatica-congenita-rx.svg",
    alt: "Flujograma: Dificultad respiratoria quirúrgica del recién nacido"
  },
  "SP-033": {
    titulo: "Derechos de los usuarios de salud",
    imagen: "flujogramas/derechos-usuario-salud-informacion.svg",
    alt: "Flujograma: Derechos de los usuarios de salud"
  },
  "HEM-006": {
    titulo: "Reacciones transfusionales agudas",
    imagen: "flujogramas/reacciones-transfusionales-trali.svg",
    alt: "Flujograma: Reacciones transfusionales agudas"
  },
  "CAR-020": {
    titulo: "Shock con ingurgitación yugular",
    imagen: "flujogramas/shock-obstructivo-taponamiento-cardiaco.svg",
    alt: "Flujograma: Shock con ingurgitación yugular"
  },
  "HEM-007": {
    titulo: "Anemia microcítica: estudio",
    imagen: "flujogramas/anemia-microcitica-estudio-ferritina.svg",
    alt: "Flujograma: Anemia microcítica: estudio"
  },
  "CAR-021": {
    titulo: "Valvulopatías: cómo reconocerlas",
    imagen: "flujogramas/valvulopatias-estenosis-mitral.svg",
    alt: "Flujograma: Valvulopatías: cómo reconocerlas"
  },
  "CAR-022": {
    titulo: "Taquicardias: enfoque inicial",
    imagen: "flujogramas/taquicardias-fibrilacion-auricular.svg",
    alt: "Flujograma: Taquicardias: enfoque inicial"
  },
  "GAS-013": {
    titulo: "Colitis crónicas: diagnóstico diferencial",
    imagen: "flujogramas/colitis-ulcerosa-espondiloartritis.svg",
    alt: "Flujograma: Colitis crónicas: diagnóstico diferencial"
  },
  "GAS-014": {
    titulo: "Tumores gástricos",
    imagen: "flujogramas/tumores-gastricos-adenocarcinoma.svg",
    alt: "Flujograma: Tumores gástricos"
  },
  "NEU-009": {
    titulo: "Lesiones pulmonares cavitadas: agente",
    imagen: "flujogramas/neumonia-cavitada-tuberculosis.svg",
    alt: "Flujograma: Lesiones pulmonares cavitadas: agente"
  },
  "NEU-010": {
    titulo: "Enfermedad pulmonar intersticial difusa",
    imagen: "flujogramas/epid-fibrosis-pulmonar-idiopatica.svg",
    alt: "Flujograma: Enfermedad pulmonar intersticial difusa"
  },
  "CAR-023": {
    titulo: "Miocardiopatías",
    imagen: "flujogramas/miocardiopatias-dilatada-alcoholica.svg",
    alt: "Flujograma: Miocardiopatías"
  },
  "PED-051": {
    titulo: "Fracturas en el niño: ¿accidente o maltrato?",
    imagen: "flujogramas/maltrato-infantil-fracturas.svg",
    alt: "Flujograma: Fracturas en el niño: ¿accidente o maltrato?"
  },
  "INF-020": {
    titulo: "Líquido cefalorraquídeo en las meningitis",
    imagen: "flujogramas/lcr-meningitis-bacteriana.svg",
    alt: "Flujograma: Líquido cefalorraquídeo en las meningitis"
  },
  "PED-052": {
    titulo: "Atresia de esófago",
    imagen: "flujogramas/atresia-esofagica-rx-torax.svg",
    alt: "Flujograma: Atresia de esófago"
  },
  "INF-021": {
    titulo: "Giardiasis: ciclo y formas",
    imagen: "flujogramas/giardiasis-ciclo-trofozoitos.svg",
    alt: "Flujograma: Giardiasis: ciclo y formas"
  },
  "PED-053": {
    titulo: "Deshidratación por diarrea: planes A, B y C",
    imagen: "flujogramas/deshidratacion-plan-c-rehidratacion.svg",
    alt: "Flujograma: Deshidratación por diarrea: planes A, B y C"
  },
  "GIN-046": {
    titulo: "Hiperémesis grave: clínica y ética",
    imagen: "flujogramas/hiperemesis-gravidica-autonomia.svg",
    alt: "Flujograma: Hiperémesis grave: clínica y ética"
  },
  "PED-054": {
    titulo: "Neonato febril: estudio",
    imagen: "flujogramas/neonato-febril-meningitis-lcr.svg",
    alt: "Flujograma: Neonato febril: estudio"
  },
  "INF-022": {
    titulo: "Dengue: fases clínicas y clasificación",
    imagen: "flujogramas/dengue-fases-clasificacion.svg",
    alt: "Flujograma: Dengue: fases clínicas y clasificación"
  },
  "SP-034": {
    titulo: "Atención primaria de salud",
    imagen: "flujogramas/atencion-primaria-salud-alma-ata.svg",
    alt: "Flujograma: Atención primaria de salud"
  },
  "SP-035": {
    titulo: "Primer nivel de atención en pandemia",
    imagen: "flujogramas/primer-nivel-pandemia-salud-mental.svg",
    alt: "Flujograma: Primer nivel de atención en pandemia"
  },
  "OFT-008": {
    titulo: "Otitis media aguda",
    imagen: "flujogramas/otitis-media-aguda-edad-gravedad.svg",
    alt: "Flujograma: Otitis media aguda"
  },
  "PED-055": {
    titulo: "Rubéola congénita",
    imagen: "flujogramas/rubeola-congenita-catarata.svg",
    alt: "Flujograma: Rubéola congénita"
  },
  "SP-036": {
    titulo: "MAIS-BFC: componentes",
    imagen: "flujogramas/mais-bfc-componente-organizacion.svg",
    alt: "Flujograma: MAIS-BFC: componentes"
  },
  "END-008": {
    titulo: "Diabetes mellitus: diagnóstico",
    imagen: "flujogramas/diabetes-diagnostico-glucemia-ayunas.svg",
    alt: "Flujograma: Diabetes mellitus: diagnóstico"
  },
  "NEF-021": {
    titulo: "Hiperplasia benigna de próstata",
    imagen: "flujogramas/hiperplasia-prostatica-alfabloqueador.svg",
    alt: "Flujograma: Hiperplasia benigna de próstata"
  },
  "END-009": {
    titulo: "Hipotensión refractaria: crisis suprarrenal",
    imagen: "flujogramas/crisis-suprarrenal-retiro-corticoides.svg",
    alt: "Flujograma: Hipotensión refractaria: crisis suprarrenal"
  },
  "SP-037": {
    titulo: "Clasificación de la persona adulta mayor",
    imagen: "flujogramas/adulto-mayor-fragil-clasificacion.svg",
    alt: "Flujograma: Clasificación de la persona adulta mayor"
  },
  "GAS-015": {
    titulo: "Dispepsia: enfoque",
    imagen: "flujogramas/dispepsia-funcional-roma-iv.svg",
    alt: "Flujograma: Dispepsia: enfoque"
  },
  "GAS-016": {
    titulo: "Hemorragia por várices esofágicas",
    imagen: "flujogramas/hemorragia-variceal-ligadura.svg",
    alt: "Flujograma: Hemorragia por várices esofágicas"
  },
  "SP-038": {
    titulo: "Evaluaciones económicas en salud",
    imagen: "flujogramas/evaluacion-economica-minimizacion-costos.svg",
    alt: "Flujograma: Evaluaciones económicas en salud"
  },
  "NEU-011": {
    titulo: "Neumoconiosis",
    imagen: "flujogramas/neumoconiosis-silicosis.svg",
    alt: "Flujograma: Neumoconiosis"
  },
  "OFT-009": {
    titulo: "Rinitis: tipos",
    imagen: "flujogramas/rinitis-alergica-diagnostico.svg",
    alt: "Flujograma: Rinitis: tipos"
  },
  "CIR-029": {
    titulo: "Colecistitis aguda",
    imagen: "flujogramas/colecistitis-aguda-tokyo.svg",
    alt: "Flujograma: Colecistitis aguda"
  },
  "NEF-022": {
    titulo: "Hiperpotasemia: cambios en el ECG",
    imagen: "flujogramas/hiperpotasemia-cambios-electrocardiograma.svg",
    alt: "Flujograma: Hiperpotasemia: cambios en el ECG"
  },
  "INF-023": {
    titulo: "Diarrea aguda: agente según la clínica",
    imagen: "flujogramas/diarrea-disenterica-shigella.svg",
    alt: "Flujograma: Diarrea aguda: agente según la clínica"
  },
  "GAS-017": {
    titulo: "Pruebas hepáticas: qué mide cada una",
    imagen: "flujogramas/pruebas-hepaticas-transaminasas-nino.svg",
    alt: "Flujograma: Pruebas hepáticas: qué mide cada una"
  },
  "GAS-018": {
    titulo: "Dolor epigástrico agudo intenso",
    imagen: "flujogramas/dolor-epigastrico-pancreatitis-aguda.svg",
    alt: "Flujograma: Dolor epigástrico agudo intenso"
  },
  "CIR-030": {
    titulo: "Shock en el paciente traumatizado",
    imagen: "flujogramas/shock-trauma-hemorragia-intraabdominal.svg",
    alt: "Flujograma: Shock en el paciente traumatizado"
  },
  "INF-024": {
    titulo: "Síndrome febril en zona tropical",
    imagen: "flujogramas/sindrome-febril-malaria-gestante.svg",
    alt: "Flujograma: Síndrome febril en zona tropical"
  },
  "GIN-047": {
    titulo: "Masa ovárica en el embarazo",
    imagen: "flujogramas/masa-ovarica-embarazo-cirugia.svg",
    alt: "Flujograma: Masa ovárica en el embarazo"
  },
  "PSI-012": {
    titulo: "Trastornos del ánimo: ¿depresión o bipolar?",
    imagen: "flujogramas/trastorno-bipolar-depresion.svg",
    alt: "Flujograma: Trastornos del ánimo: ¿depresión o bipolar?"
  },
  "HEM-008": {
    titulo: "Lesiones óseas líticas: diagnóstico",
    imagen: "flujogramas/mieloma-multiple-crab.svg",
    alt: "Flujograma: Lesiones óseas líticas: diagnóstico"
  },
  "HEM-009": {
    titulo: "Microangiopatías trombóticas",
    imagen: "flujogramas/microangiopatia-trombotica-ptt-plasma.svg",
    alt: "Flujograma: Microangiopatías trombóticas"
  },
  "HEM-010": {
    titulo: "Déficit de hierro: etapas",
    imagen: "flujogramas/ferropenia-etapas-anemia.svg",
    alt: "Flujograma: Déficit de hierro: etapas"
  },
  "NEU-012": {
    titulo: "Acidosis respiratoria aguda: hipoventilación",
    imagen: "flujogramas/hipoventilacion-benzodiacepinas-soporte.svg",
    alt: "Flujograma: Acidosis respiratoria aguda: hipoventilación"
  },
  "NEF-023": {
    titulo: "Lesión renal aguda: estadios y manejo",
    imagen: "flujogramas/lesion-renal-aguda-postoperatoria-volumen.svg",
    alt: "Flujograma: Lesión renal aguda: estadios y manejo"
  },
  "END-010": {
    titulo: "Hipotiroidismo y bocio",
    imagen: "flujogramas/hipotiroidismo-tiroiditis-hashimoto.svg",
    alt: "Flujograma: Hipotiroidismo y bocio"
  },
  "END-011": {
    titulo: "Emergencias glucémicas en el diabético",
    imagen: "flujogramas/emergencias-glucemicas-hiperosmolar.svg",
    alt: "Flujograma: Emergencias glucémicas en el diabético"
  },
  "END-012": {
    titulo: "Hipoglucemia en el diabético",
    imagen: "flujogramas/hipoglucemia-grave-glucosa-ev.svg",
    alt: "Flujograma: Hipoglucemia en el diabético"
  },
  "GAS-019": {
    titulo: "Ascitis con confusión: ¿qué falla?",
    imagen: "flujogramas/ascitis-confusion-falla-hepatica-cronica.svg",
    alt: "Flujograma: Ascitis con confusión: ¿qué falla?"
  },
  "NRL-013": {
    titulo: "Coma de causa desconocida: primeras medidas",
    imagen: "flujogramas/coma-alcoholico-tiamina-ev.svg",
    alt: "Flujograma: Coma de causa desconocida: primeras medidas"
  },
  "NEU-013": {
    titulo: "Exacerbación de la EPOC",
    imagen: "flujogramas/exacerbacion-epoc-antibiotico.svg",
    alt: "Flujograma: Exacerbación de la EPOC"
  },
  "INF-025": {
    titulo: "Parásitos intestinales: vías de ingreso",
    imagen: "flujogramas/parasitos-via-ingreso-penetracion-cutanea.svg",
    alt: "Flujograma: Parásitos intestinales: vías de ingreso"
  },
  "INF-026": {
    titulo: "Infecciones granulomatosas de zona rural",
    imagen: "flujogramas/micosis-endemicas-paracoccidioidomicosis.svg",
    alt: "Flujograma: Infecciones granulomatosas de zona rural"
  },
  "NEU-014": {
    titulo: "Neumonía típica y atípica",
    imagen: "flujogramas/neumonia-atipica-mycoplasma.svg",
    alt: "Flujograma: Neumonía típica y atípica"
  },
  "NEU-015": {
    titulo: "Neumonía adquirida en la comunidad: tratamiento",
    imagen: "flujogramas/neumonia-comunidad-curb65-tratamiento.svg",
    alt: "Flujograma: Neumonía adquirida en la comunidad: tratamiento"
  },
  "CAR-024": {
    titulo: "Insuficiencia cardiaca aguda: perfiles",
    imagen: "flujogramas/insuficiencia-cardiaca-aguda-perfiles.svg",
    alt: "Flujograma: Insuficiencia cardiaca aguda: perfiles"
  },
  "CAR-025": {
    titulo: "Criterios de Framingham",
    imagen: "flujogramas/criterios-framingham-insuficiencia-cardiaca.svg",
    alt: "Flujograma: Criterios de Framingham"
  },
  "CAR-026": {
    titulo: "Infarto con ST elevado: objetivo del tratamiento",
    imagen: "flujogramas/infarto-st-elevado-limitar-necrosis.svg",
    alt: "Flujograma: Infarto con ST elevado: objetivo del tratamiento"
  },
  "GAS-020": {
    titulo: "Derrame pleural: estudio del líquido",
    imagen: "flujogramas/derrame-pleural-pancreatico-amilasa.svg",
    alt: "Flujograma: Derrame pleural: estudio del líquido"
  },
  "NRL-014": {
    titulo: "Dolor neuropático diabético",
    imagen: "flujogramas/dolor-neuropatico-diabetico-gabapentina.svg",
    alt: "Flujograma: Dolor neuropático diabético"
  },
  "END-013": {
    titulo: "Hipocalcemia tras tiroidectomía",
    imagen: "flujogramas/hipocalcemia-postiroidectomia-calcio-ionico.svg",
    alt: "Flujograma: Hipocalcemia tras tiroidectomía"
  },
  "NEF-024": {
    titulo: "Alteración de conciencia en el hospitalizado",
    imagen: "flujogramas/hiponatremia-hospitalaria-dosaje-sodio.svg",
    alt: "Flujograma: Alteración de conciencia en el hospitalizado"
  },
  "NEF-025": {
    titulo: "Hiperpotasemia: gravedad y manejo",
    imagen: "flujogramas/hiperpotasemia-gravedad-manejo.svg",
    alt: "Flujograma: Hiperpotasemia: gravedad y manejo"
  },
  "REU-014": {
    titulo: "Inflamación del pliegue ungueal",
    imagen: "flujogramas/paroniquia-cronica-candidiasica.svg",
    alt: "Flujograma: Inflamación del pliegue ungueal"
  },
  "HEM-011": {
    titulo: "Anemias microcíticas: perfil de hierro",
    imagen: "flujogramas/anemia-enfermedad-cronica-perfil-hierro.svg",
    alt: "Flujograma: Anemias microcíticas: perfil de hierro"
  },
  "CIR-031": {
    titulo: "Ritmos de paro cardiaco",
    imagen: "flujogramas/ritmos-paro-disociacion-electromecanica.svg",
    alt: "Flujograma: Ritmos de paro cardiaco"
  },
  "CB-015": {
    titulo: "Shock hipovolémico: mecanismos compensadores",
    imagen: "flujogramas/shock-hipovolemico-compensacion-taquicardia.svg",
    alt: "Flujograma: Shock hipovolémico: mecanismos compensadores"
  },
  "REU-015": {
    titulo: "Anafilaxia: gravedad y tratamiento",
    imagen: "flujogramas/anafilaxia-grados-adrenalina.svg",
    alt: "Flujograma: Anafilaxia: gravedad y tratamiento"
  },
  "NEU-016": {
    titulo: "Tromboembolismo pulmonar: probabilidad clínica",
    imagen: "flujogramas/tromboembolismo-pulmonar-wells.svg",
    alt: "Flujograma: Tromboembolismo pulmonar: probabilidad clínica"
  },
  "NEF-026": {
    titulo: "Síndrome de aplastamiento y rabdomiólisis",
    imagen: "flujogramas/sindrome-aplastamiento-rabdomiolisis-renal.svg",
    alt: "Flujograma: Síndrome de aplastamiento y rabdomiólisis"
  },
  "CB-016": {
    titulo: "Toxíndromes: reconocerlos al pie de la cama",
    imagen: "flujogramas/toxindromes-colinergico-organofosforados.svg",
    alt: "Flujograma: Toxíndromes: reconocerlos al pie de la cama"
  },
  "NEU-017": {
    titulo: "Derrame pleural linfocítico",
    imagen: "flujogramas/derrame-pleural-linfocitico-ada-tuberculosis.svg",
    alt: "Flujograma: Derrame pleural linfocítico"
  },
  "CIR-032": {
    titulo: "Enfermedad arterial periférica: índice tobillo-brazo",
    imagen: "flujogramas/claudicacion-indice-tobillo-brazo.svg",
    alt: "Flujograma: Enfermedad arterial periférica: índice tobillo-brazo"
  },
  "CAR-027": {
    titulo: "Angioedema: ¿por qué fármaco?",
    imagen: "flujogramas/angioedema-ieca-bradicinina.svg",
    alt: "Flujograma: Angioedema: ¿por qué fármaco?"
  },
  "PED-056": {
    titulo: "Anemia del prematuro",
    imagen: "flujogramas/anemia-prematuro-nadir-hemoglobina.svg",
    alt: "Flujograma: Anemia del prematuro"
  },
  "PED-057": {
    titulo: "Edema en el niño: nefrótico o nefrítico",
    imagen: "flujogramas/edema-nino-sindrome-nefrotico.svg",
    alt: "Flujograma: Edema en el niño: nefrótico o nefrítico"
  },
  "END-014": {
    titulo: "Pubertad precoz",
    imagen: "flujogramas/pubertad-precoz-prueba-gnrh.svg",
    alt: "Flujograma: Pubertad precoz"
  },
  "PED-058": {
    titulo: "Convulsiones neonatales por asfixia",
    imagen: "flujogramas/encefalopatia-hipoxica-convulsiones-fenobarbital.svg",
    alt: "Flujograma: Convulsiones neonatales por asfixia"
  },
  "PED-059": {
    titulo: "Invaginación intestinal",
    imagen: "flujogramas/invaginacion-intestinal-lactante.svg",
    alt: "Flujograma: Invaginación intestinal"
  },
  "PED-060": {
    titulo: "Lactante con sospecha de meningitis",
    imagen: "flujogramas/meningitis-lactante-estudio-lcr.svg",
    alt: "Flujograma: Lactante con sospecha de meningitis"
  },
  "PED-061": {
    titulo: "Infección respiratoria alta en el lactante",
    imagen: "flujogramas/resfrio-comun-lactante.svg",
    alt: "Flujograma: Infección respiratoria alta en el lactante"
  },
  "INF-027": {
    titulo: "Síndrome de Löffler",
    imagen: "flujogramas/sindrome-loffler-ascaris-albendazol.svg",
    alt: "Flujograma: Síndrome de Löffler"
  },
  "PED-062": {
    titulo: "Deshidratación: clasificación clínica",
    imagen: "flujogramas/deshidratacion-clasificacion-algun-grado.svg",
    alt: "Flujograma: Deshidratación: clasificación clínica"
  },
  "PED-063": {
    titulo: "Síndrome urémico hemolítico",
    imagen: "flujogramas/sindrome-uremico-hemolitico-nino.svg",
    alt: "Flujograma: Síndrome urémico hemolítico"
  },
  "PED-064": {
    titulo: "Crup: gravedad con la escala de Westley",
    imagen: "flujogramas/crup-laringotraqueitis-westley.svg",
    alt: "Flujograma: Crup: gravedad con la escala de Westley"
  },
  "REU-016": {
    titulo: "Lesiones vesículo-costrosas en el niño",
    imagen: "flujogramas/impetigo-costras-melicericas.svg",
    alt: "Flujograma: Lesiones vesículo-costrosas en el niño"
  },
  "REU-017": {
    titulo: "Alopecia en placas en el niño",
    imagen: "flujogramas/alopecia-nino-tina-capitis.svg",
    alt: "Flujograma: Alopecia en placas en el niño"
  },
  "HEM-012": {
    titulo: "Recuento absoluto de neutrófilos",
    imagen: "flujogramas/recuento-absoluto-neutrofilos-calculo.svg",
    alt: "Flujograma: Recuento absoluto de neutrófilos"
  },
  "CIR-033": {
    titulo: "Apendicitis: escala de Alvarado",
    imagen: "flujogramas/apendicitis-escala-alvarado.svg",
    alt: "Flujograma: Apendicitis: escala de Alvarado"
  },
  "CIR-034": {
    titulo: "Lesiones vasculares tardías tras un trauma",
    imagen: "flujogramas/fistula-arteriovenosa-traumatica.svg",
    alt: "Flujograma: Lesiones vasculares tardías tras un trauma"
  },
  "CIR-035": {
    titulo: "Insuficiencia venosa crónica",
    imagen: "flujogramas/insuficiencia-venosa-cronica-ceap.svg",
    alt: "Flujograma: Insuficiencia venosa crónica"
  },
  "CIR-036": {
    titulo: "Hemotórax traumático",
    imagen: "flujogramas/hemotorax-masivo-toracotomia.svg",
    alt: "Flujograma: Hemotórax traumático"
  },
  "OFT-010": {
    titulo: "Fracturas de la órbita",
    imagen: "flujogramas/fractura-orbita-blow-out-piso.svg",
    alt: "Flujograma: Fracturas de la órbita"
  },
  "OFT-011": {
    titulo: "Ojo rojo: tipos de conjuntivitis",
    imagen: "flujogramas/conjuntivitis-adenovirus-queratoconjuntivitis.svg",
    alt: "Flujograma: Ojo rojo: tipos de conjuntivitis"
  },
  "NEF-027": {
    titulo: "Masa testicular indolora",
    imagen: "flujogramas/masa-testicular-indolora-cancer.svg",
    alt: "Flujograma: Masa testicular indolora"
  },
  "NEF-028": {
    titulo: "Litiasis urinaria: qué imagen pedir",
    imagen: "flujogramas/colico-renal-imagenes-tomografia.svg",
    alt: "Flujograma: Litiasis urinaria: qué imagen pedir"
  },
  "TRA-010": {
    titulo: "Síndrome compartimental agudo",
    imagen: "flujogramas/sindrome-compartimental-fractura-tibia.svg",
    alt: "Flujograma: Síndrome compartimental agudo"
  },
  "TRA-011": {
    titulo: "Síndrome de embolia grasa",
    imagen: "flujogramas/embolia-grasa-schonfeld.svg",
    alt: "Flujograma: Síndrome de embolia grasa"
  },
  "CIR-037": {
    titulo: "Dolor perianal agudo",
    imagen: "flujogramas/dolor-perianal-absceso.svg",
    alt: "Flujograma: Dolor perianal agudo"
  },
  "CIR-038": {
    titulo: "Masa que sale por el ano",
    imagen: "flujogramas/masa-anal-prolapso-rectal.svg",
    alt: "Flujograma: Masa que sale por el ano"
  },
  "OFT-012": {
    titulo: "Rinitis crónica: alérgica o no alérgica",
    imagen: "flujogramas/rinitis-alergica-eosinofilica-diferencial.svg",
    alt: "Flujograma: Rinitis crónica: alérgica o no alérgica"
  },
  "OFT-013": {
    titulo: "Epistaxis: medidas según el caso",
    imagen: "flujogramas/epistaxis-traumatica-taponamiento-anterior.svg",
    alt: "Flujograma: Epistaxis: medidas según el caso"
  },
  "NRL-015": {
    titulo: "Hallazgos en la TC cerebral",
    imagen: "flujogramas/hipertension-endocraneana-lesion-anillo.svg",
    alt: "Flujograma: Hallazgos en la TC cerebral"
  },
  "NRL-016": {
    titulo: "TEC con intervalo lúcido",
    imagen: "flujogramas/tec-intervalo-lucido-hematoma-epidural.svg",
    alt: "Flujograma: TEC con intervalo lúcido"
  },
  "PED-065": {
    titulo: "Dificultad respiratoria neonatal con abdomen excavado",
    imagen: "flujogramas/distres-neonatal-hernia-diafragmatica-clinica.svg",
    alt: "Flujograma: Dificultad respiratoria neonatal con abdomen excavado"
  },
  "SP-039": {
    titulo: "Principios bioéticos en la práctica",
    imagen: "flujogramas/autonomia-anticoncepcion-emergencia-violacion.svg",
    alt: "Flujograma: Principios bioéticos en la práctica"
  },
  "GIN-048": {
    titulo: "Desprendimiento prematuro de placenta: gravedad",
    imagen: "flujogramas/desprendimiento-placenta-grado-obito.svg",
    alt: "Flujograma: Desprendimiento prematuro de placenta: gravedad"
  },
  "GIN-049": {
    titulo: "Fiebre en el puerperio",
    imagen: "flujogramas/fiebre-puerperal-endometritis.svg",
    alt: "Flujograma: Fiebre en el puerperio"
  },
  "GIN-050": {
    titulo: "Fiebre en la gestante con membranas rotas",
    imagen: "flujogramas/fiebre-gestante-rpm-corioamnionitis.svg",
    alt: "Flujograma: Fiebre en la gestante con membranas rotas"
  },
  "GIN-051": {
    titulo: "Infección urinaria en el embarazo: antibiótico",
    imagen: "flujogramas/pielonefritis-gestante-antibiotico.svg",
    alt: "Flujograma: Infección urinaria en el embarazo: antibiótico"
  },
  "GIN-052": {
    titulo: "Embarazo prolongado: índice de Bishop",
    imagen: "flujogramas/embarazo-prolongado-bishop-induccion.svg",
    alt: "Flujograma: Embarazo prolongado: índice de Bishop"
  },
  "GIN-053": {
    titulo: "Distocia de hombros: secuencia de maniobras",
    imagen: "flujogramas/distocia-hombros-mcroberts.svg",
    alt: "Flujograma: Distocia de hombros: secuencia de maniobras"
  },
  "GIN-054": {
    titulo: "Sangrado posmenopáusico",
    imagen: "flujogramas/sangrado-posmenopausico-biopsia-endometrio.svg",
    alt: "Flujograma: Sangrado posmenopáusico"
  },
  "GIN-055": {
    titulo: "Flujo vaginal: tipos de vaginitis",
    imagen: "flujogramas/vaginitis-mixta-metronidazol-clotrimazol.svg",
    alt: "Flujograma: Flujo vaginal: tipos de vaginitis"
  },
  "GIN-056": {
    titulo: "Tumores de ovario según la edad",
    imagen: "flujogramas/tumores-ovaricos-nina-celulas-germinales.svg",
    alt: "Flujograma: Tumores de ovario según la edad"
  },
  "PED-066": {
    titulo: "Niño de 6 años sin vacunas",
    imagen: "flujogramas/vacunacion-tardia-seis-anos-hib.svg",
    alt: "Flujograma: Niño de 6 años sin vacunas"
  },
  "CB-017": {
    titulo: "Apoptosis",
    imagen: "flujogramas/apoptosis-dano-adn-p53.svg",
    alt: "Flujograma: Apoptosis"
  },
  "CB-018": {
    titulo: "Eficacia, efectividad y eficiencia",
    imagen: "flujogramas/eficacia-efectividad-eficiencia.svg",
    alt: "Flujograma: Eficacia, efectividad y eficiencia"
  },
  "CB-019": {
    titulo: "Mialgias tras iniciar un hipolipemiante",
    imagen: "flujogramas/mialgias-estatinas-reaccion-adversa.svg",
    alt: "Flujograma: Mialgias tras iniciar un hipolipemiante"
  },
  "CB-020": {
    titulo: "Músculos intrínsecos de la laringe",
    imagen: "flujogramas/musculos-laringe-cricoaritenoideo-posterior.svg",
    alt: "Flujograma: Músculos intrínsecos de la laringe"
  },
  "GIN-057": {
    titulo: "Claves obstétricas",
    imagen: "flujogramas/claves-obstetricas-roja-azul-amarilla.svg",
    alt: "Flujograma: Claves obstétricas"
  },
  "NEU-018": {
    titulo: "Dolor de hombro en un fumador",
    imagen: "flujogramas/dolor-hombro-fumador-pancoast.svg",
    alt: "Flujograma: Dolor de hombro en un fumador"
  },
  "SP-040": {
    titulo: "Determinantes sociales de la salud",
    imagen: "flujogramas/determinantes-sociales-estructurales-etnia.svg",
    alt: "Flujograma: Determinantes sociales de la salud"
  },
  "SP-041": {
    titulo: "Diseños de estudio: cómo elegir",
    imagen: "flujogramas/disenos-estudio-cohorte-matriz.svg",
    alt: "Flujograma: Diseños de estudio: cómo elegir"
  },
  "CB-021": {
    titulo: "Antídotos de uso frecuente",
    imagen: "flujogramas/antidotos-sarin-atropina.svg",
    alt: "Flujograma: Antídotos de uso frecuente"
  },
  "SP-042": {
    titulo: "Ética en la investigación con personas",
    imagen: "flujogramas/etica-investigacion-helsinki-comite.svg",
    alt: "Flujograma: Ética en la investigación con personas"
  },
  "PED-067": {
    titulo: "Lactante con tos y sibilancias",
    imagen: "flujogramas/lactante-sibilancias-bronquiolitis.svg",
    alt: "Flujograma: Lactante con tos y sibilancias"
  },
  "END-015": {
    titulo: "Hipercolesterolemia familiar",
    imagen: "flujogramas/hipercolesterolemia-familiar-dutch-lipid.svg",
    alt: "Flujograma: Hipercolesterolemia familiar"
  },
  "GIN-058": {
    titulo: "Flujo espumoso con colpitis en fresa",
    imagen: "flujogramas/flujo-espumoso-colpitis-fresa-tricomonas.svg",
    alt: "Flujograma: Flujo espumoso con colpitis en fresa"
  },
  "CB-022": {
    titulo: "Coma de origen tóxico",
    imagen: "flujogramas/coma-toxico-benzodiacepinas-flumazenil.svg",
    alt: "Flujograma: Coma de origen tóxico"
  },
  "HEM-013": {
    titulo: "Adenopatías: cuándo biopsiar",
    imagen: "flujogramas/adenopatias-generalizadas-biopsia-linfoma.svg",
    alt: "Flujograma: Adenopatías: cuándo biopsiar"
  },
  "SP-043": {
    titulo: "Estudio experimental",
    imagen: "flujogramas/piramide-evidencia-estudio-experimental.svg",
    alt: "Flujograma: Estudio experimental"
  },
  "OFT-014": {
    titulo: "Lactante febril: qué explorar",
    imagen: "flujogramas/lactante-otalgia-otoscopia.svg",
    alt: "Flujograma: Lactante febril: qué explorar"
  },
  "NRL-017": {
    titulo: "Síndromes medulares incompletos",
    imagen: "flujogramas/sindromes-medulares-brown-sequard.svg",
    alt: "Flujograma: Síndromes medulares incompletos"
  },
  "PED-068": {
    titulo: "Lesiones en piel de distinta antigüedad",
    imagen: "flujogramas/lactante-equimosis-patron-maltrato.svg",
    alt: "Flujograma: Lesiones en piel de distinta antigüedad"
  },
  "PED-069": {
    titulo: "Sepsis neonatal: temprana y tardía",
    imagen: "flujogramas/sepsis-neonatal-temprana-tardia-matriz.svg",
    alt: "Flujograma: Sepsis neonatal: temprana y tardía"
  },
  "SP-044": {
    titulo: "Habilidades de gestión en salud",
    imagen: "flujogramas/gestion-salud-liderazgo-vacunacion.svg",
    alt: "Flujograma: Habilidades de gestión en salud"
  },
  "SP-045": {
    titulo: "Mordeduras por perros callejeros: coordinación",
    imagen: "flujogramas/mordeduras-perros-callejeros-municipalidad.svg",
    alt: "Flujograma: Mordeduras por perros callejeros: coordinación"
  },
  "GIN-059": {
    titulo: "Hemorragia posparto: las 4 T",
    imagen: "flujogramas/hemorragia-posparto-atonia-uterina.svg",
    alt: "Flujograma: Hemorragia posparto: las 4 T"
  },
  "PED-070": {
    titulo: "Alimentación complementaria y anemia",
    imagen: "flujogramas/alimentacion-complementaria-hierro-anemia.svg",
    alt: "Flujograma: Alimentación complementaria y anemia"
  },
  "REU-018": {
    titulo: "Líquido sinovial: clasificación",
    imagen: "flujogramas/liquido-sinovial-clasificacion.svg",
    alt: "Flujograma: Líquido sinovial: clasificación"
  },
  "NEF-029": {
    titulo: "Oliguria tras aplastamiento: qué pedir",
    imagen: "flujogramas/aplastamiento-oliguria-cpk.svg",
    alt: "Flujograma: Oliguria tras aplastamiento: qué pedir"
  },
  "OFT-015": {
    titulo: "Glaucoma agudo: elegir el fármaco",
    imagen: "flujogramas/glaucoma-agudo-asma-alergia-sulfas-manitol.svg",
    alt: "Flujograma: Glaucoma agudo: elegir el fármaco"
  },
  "GIN-060": {
    titulo: "Infección urinaria en el embarazo",
    imagen: "flujogramas/itu-embarazo-profilaxis-nitrofurantoina.svg",
    alt: "Flujograma: Infección urinaria en el embarazo"
  },
  "NRL-018": {
    titulo: "Ataque isquémico transitorio: riesgo",
    imagen: "flujogramas/ataque-isquemico-transitorio-abcd2.svg",
    alt: "Flujograma: Ataque isquémico transitorio: riesgo"
  },
  "CIR-039": {
    titulo: "Politraumatizado: escala de Glasgow",
    imagen: "flujogramas/politraumatizado-glasgow-intubacion.svg",
    alt: "Flujograma: Politraumatizado: escala de Glasgow"
  },
  "NEU-019": {
    titulo: "Masa pulmonar: cómo obtener la biopsia",
    imagen: "flujogramas/masa-pulmonar-central-broncofibroscopia.svg",
    alt: "Flujograma: Masa pulmonar: cómo obtener la biopsia"
  },
  "PSI-013": {
    titulo: "Síntomas emocionales tras un cambio de vida",
    imagen: "flujogramas/migracion-trastorno-adaptacion.svg",
    alt: "Flujograma: Síntomas emocionales tras un cambio de vida"
  },
  "PED-071": {
    titulo: "Vómito bilioso en el recién nacido",
    imagen: "flujogramas/vomito-bilioso-down-atresia-duodenal.svg",
    alt: "Flujograma: Vómito bilioso en el recién nacido"
  },
  "PED-072": {
    titulo: "Sarampión: evolución clínica",
    imagen: "flujogramas/sarampion-fases-vacunacion.svg",
    alt: "Flujograma: Sarampión: evolución clínica"
  },
  "PED-073": {
    titulo: "Intoxicación por insecticidas",
    imagen: "flujogramas/intoxicacion-insecticida-cosecha.svg",
    alt: "Flujograma: Intoxicación por insecticidas"
  },
  "SP-046": {
    titulo: "Análisis de situación de salud (ASIS)",
    imagen: "flujogramas/asis-analisis-del-entorno.svg",
    alt: "Flujograma: Análisis de situación de salud (ASIS)"
  },
  "REU-019": {
    titulo: "Arteritis de células gigantes",
    imagen: "flujogramas/arteritis-celulas-gigantes-corticoide.svg",
    alt: "Flujograma: Arteritis de células gigantes"
  },
  "END-016": {
    titulo: "Síndrome hipermetabólico",
    imagen: "flujogramas/hipermetabolismo-hipertiroidismo.svg",
    alt: "Flujograma: Síndrome hipermetabólico"
  },
  "GIN-061": {
    titulo: "Mama dolorosa en el puerperio",
    imagen: "flujogramas/mama-dolorosa-puerperio-mastitis.svg",
    alt: "Flujograma: Mama dolorosa en el puerperio"
  },
  "GIN-062": {
    titulo: "Sangrado en el tercer trimestre: dolor y origen",
    imagen: "flujogramas/sangrado-tercer-trimestre-rotura-uterina.svg",
    alt: "Flujograma: Sangrado en el tercer trimestre: dolor y origen"
  },
  "SP-047": {
    titulo: "Aumento de tuberculosis: ¿qué influye más?",
    imagen: "flujogramas/tuberculosis-hacinamiento-determinantes.svg",
    alt: "Flujograma: Aumento de tuberculosis: ¿qué influye más?"
  },
  "NEF-030": {
    titulo: "Dolor lumbar agudo con hematuria",
    imagen: "flujogramas/dolor-lumbar-agudo-litiasis-renal.svg",
    alt: "Flujograma: Dolor lumbar agudo con hematuria"
  },
  "PED-074": {
    titulo: "Crecimiento del lactante",
    imagen: "flujogramas/ganancia-peso-insuficiente-visita-domiciliaria.svg",
    alt: "Flujograma: Crecimiento del lactante"
  },
  "CB-023": {
    titulo: "Intoxicación por monóxido de carbono",
    imagen: "flujogramas/monoxido-carbono-estufa-oxigeno.svg",
    alt: "Flujograma: Intoxicación por monóxido de carbono"
  },
  "REU-020": {
    titulo: "Acné: formas de gravedad",
    imagen: "flujogramas/acne-fulminante-fiebre-artralgias.svg",
    alt: "Flujograma: Acné: formas de gravedad"
  },
  "GAS-021": {
    titulo: "Pancreatitis aguda: primeras 72 horas",
    imagen: "flujogramas/pancreatitis-hipertrigliceridemia-hidratacion.svg",
    alt: "Flujograma: Pancreatitis aguda: primeras 72 horas"
  },
  "PED-075": {
    titulo: "Vómitos en el lactante pequeño",
    imagen: "flujogramas/vomitos-lactante-hipertrofia-piloro.svg",
    alt: "Flujograma: Vómitos en el lactante pequeño"
  },
  "PED-076": {
    titulo: "Neumonía en el niño: tipos",
    imagen: "flujogramas/neumonia-nino-tipos-comunidad.svg",
    alt: "Flujograma: Neumonía en el niño: tipos"
  },
  "CIR-040": {
    titulo: "Herida precordial con shock",
    imagen: "flujogramas/herida-precordial-taponamiento-pericardiocentesis.svg",
    alt: "Flujograma: Herida precordial con shock"
  },
  "SP-048": {
    titulo: "Voluntades anticipadas",
    imagen: "flujogramas/voluntad-anticipada-autonomia-ventilacion.svg",
    alt: "Flujograma: Voluntades anticipadas"
  },
  "TRA-012": {
    titulo: "Fracturas del brazo y nervio afectado",
    imagen: "flujogramas/fractura-humero-nervios-mano-pendula.svg",
    alt: "Flujograma: Fracturas del brazo y nervio afectado"
  },
  "PSI-014": {
    titulo: "Crisis de pánico",
    imagen: "flujogramas/crisis-panico-curso-sintomas.svg",
    alt: "Flujograma: Crisis de pánico"
  },
  "GAS-022": {
    titulo: "Esteatorrea en el alcohólico",
    imagen: "flujogramas/esteatorrea-pancreatitis-cronica-insuficiencia.svg",
    alt: "Flujograma: Esteatorrea en el alcohólico"
  },
  "END-017": {
    titulo: "Hipertensión secundaria: causas endocrinas",
    imagen: "flujogramas/hipertension-paroxistica-feocromocitoma.svg",
    alt: "Flujograma: Hipertensión secundaria: causas endocrinas"
  },
  "PED-077": {
    titulo: "Convulsión febril: simple o compleja",
    imagen: "flujogramas/convulsion-febril-compleja-criterios.svg",
    alt: "Flujograma: Convulsión febril: simple o compleja"
  },
  "GIN-063": {
    titulo: "Rotura prematura de membranas: manejo según semanas",
    imagen: "flujogramas/rotura-membranas-pretermino-manejo.svg",
    alt: "Flujograma: Rotura prematura de membranas: manejo según semanas"
  },
  "NEU-020": {
    titulo: "Mecanismos de hipoxemia",
    imagen: "flujogramas/mecanismos-hipoxemia-epoc-vq.svg",
    alt: "Flujograma: Mecanismos de hipoxemia"
  },
  "PED-078": {
    titulo: "Lactante que suda y se cansa al lactar",
    imagen: "flujogramas/lactante-sudoracion-lactancia-insuficiencia-cardiaca.svg",
    alt: "Flujograma: Lactante que suda y se cansa al lactar"
  },
  "CIR-041": {
    titulo: "Quemado con compromiso de la vía aérea",
    imagen: "flujogramas/quemadura-facial-estridor-intubacion.svg",
    alt: "Flujograma: Quemado con compromiso de la vía aérea"
  },
  "CAR-028": {
    titulo: "Arritmias: con pulso o sin pulso",
    imagen: "flujogramas/arritmias-pulso-desfibrilacion-cardioversion.svg",
    alt: "Flujograma: Arritmias: con pulso o sin pulso"
  },
  "GAS-023": {
    titulo: "Megacolon tóxico",
    imagen: "flujogramas/megacolon-toxico-criterios-jalan.svg",
    alt: "Flujograma: Megacolon tóxico"
  },
  "GIN-064": {
    titulo: "Diabetes gestacional: cuándo tamizar",
    imagen: "flujogramas/diabetes-gestacional-tamizaje-24-28.svg",
    alt: "Flujograma: Diabetes gestacional: cuándo tamizar"
  },
  "GIN-065": {
    titulo: "Prevención de la endometritis puerperal",
    imagen: "flujogramas/prevencion-endometritis-tactos-vaginales.svg",
    alt: "Flujograma: Prevención de la endometritis puerperal"
  },
  "REU-021": {
    titulo: "Dermatitis atópica: tratamiento escalonado",
    imagen: "flujogramas/dermatitis-atopica-escalera-emolientes.svg",
    alt: "Flujograma: Dermatitis atópica: tratamiento escalonado"
  },
  "INF-028": {
    titulo: "SARS-CoV-2: ciclo de replicación",
    imagen: "flujogramas/sars-cov-2-ciclo-ace2.svg",
    alt: "Flujograma: SARS-CoV-2: ciclo de replicación"
  },
  "CIR-042": {
    titulo: "Taponamiento traumático: qué hacer",
    imagen: "flujogramas/taponamiento-traumatico-toracotomia.svg",
    alt: "Flujograma: Taponamiento traumático: qué hacer"
  },
  "CIR-043": {
    titulo: "Coledocolitiasis: conducta según probabilidad",
    imagen: "flujogramas/coledocolitiasis-cpre-papilotomia.svg",
    alt: "Flujograma: Coledocolitiasis: conducta según probabilidad"
  },
  "GIN-066": {
    titulo: "Prurito vulvar en la posmenopausia",
    imagen: "flujogramas/prurito-vulvar-posmenopausia-atrofia.svg",
    alt: "Flujograma: Prurito vulvar en la posmenopausia"
  },
  "HEM-014": {
    titulo: "Niña con palidez, dolor óseo y visceromegalia",
    imagen: "flujogramas/nina-citopenias-hepatoesplenomegalia-lla.svg",
    alt: "Flujograma: Niña con palidez, dolor óseo y visceromegalia"
  },
  "CIR-044": {
    titulo: "Infecciones de partes blandas: gravedad",
    imagen: "flujogramas/infeccion-partes-blandas-fascitis-necrotizante.svg",
    alt: "Flujograma: Infecciones de partes blandas: gravedad"
  },
  "GIN-067": {
    titulo: "Tipos de shock en obstetricia",
    imagen: "flujogramas/shock-obstetrico-tipos-hipovolemico.svg",
    alt: "Flujograma: Tipos de shock en obstetricia"
  },
  "PED-079": {
    titulo: "Tos ferina",
    imagen: "flujogramas/tos-ferina-fases-azitromicina.svg",
    alt: "Flujograma: Tos ferina"
  },
  "CIR-045": {
    titulo: "Obstrucción de colon en la altura",
    imagen: "flujogramas/obstruccion-colon-altura-volvulo-sigmoides.svg",
    alt: "Flujograma: Obstrucción de colon en la altura"
  },
  "NEU-021": {
    titulo: "Disnea crónica con acropaquias",
    imagen: "flujogramas/disnea-cronica-crepitantes-epid.svg",
    alt: "Flujograma: Disnea crónica con acropaquias"
  },
  "CAR-029": {
    titulo: "Cuidados posparo: metas ventilatorias",
    imagen: "flujogramas/cuidados-posparo-paco2-ventilacion.svg",
    alt: "Flujograma: Cuidados posparo: metas ventilatorias"
  },
  "CIR-046": {
    titulo: "Fiebre posoperatoria según el día",
    imagen: "flujogramas/fiebre-postoperatoria-atelectasia.svg",
    alt: "Flujograma: Fiebre posoperatoria según el día"
  },
  "INF-029": {
    titulo: "Fiebre prolongada en zona tropical",
    imagen: "flujogramas/fiebre-escalofrios-esplenomegalia-malaria.svg",
    alt: "Flujograma: Fiebre prolongada en zona tropical"
  },
  "CIR-047": {
    titulo: "Tipos de cierre de heridas",
    imagen: "flujogramas/cicatrizacion-cierre-tercera-intencion.svg",
    alt: "Flujograma: Tipos de cierre de heridas"
  },
  "SP-049": {
    titulo: "Medidas de asociación y diseños",
    imagen: "flujogramas/medidas-asociacion-odds-ratio-casos-controles.svg",
    alt: "Flujograma: Medidas de asociación y diseños"
  },
  "NRL-019": {
    titulo: "Corea de Sydenham: criterios de Jones",
    imagen: "flujogramas/corea-sydenham-criterios-jones.svg",
    alt: "Flujograma: Corea de Sydenham: criterios de Jones"
  },
  "HEM-015": {
    titulo: "Células de la mucosa gástrica",
    imagen: "flujogramas/celulas-gastricas-anemia-perniciosa.svg",
    alt: "Flujograma: Células de la mucosa gástrica"
  },
  "GIN-068": {
    titulo: "Tamizaje de diabetes gestacional en dos pasos",
    imagen: "flujogramas/test-osullivan-positivo-ptog.svg",
    alt: "Flujograma: Tamizaje de diabetes gestacional en dos pasos"
  },
  "PED-080": {
    titulo: "Fenilcetonuria en el tamizaje neonatal",
    imagen: "flujogramas/tamizaje-neonatal-fenilcetonuria-dieta.svg",
    alt: "Flujograma: Fenilcetonuria en el tamizaje neonatal"
  },
  "OFT-016": {
    titulo: "Epistaxis anterior: manejo escalonado",
    imagen: "flujogramas/epistaxis-anterior-hipertenso-compresion.svg",
    alt: "Flujograma: Epistaxis anterior: manejo escalonado"
  },
  "NRL-020": {
    titulo: "Déficit neurológico que se recupera",
    imagen: "flujogramas/deficit-focal-transitorio-anciano-ait.svg",
    alt: "Flujograma: Déficit neurológico que se recupera"
  },
  "HEM-016": {
    titulo: "Leucocitosis con esplenomegalia",
    imagen: "flujogramas/leucocitosis-esplenomegalia-leucemia-mieloide-cronica.svg",
    alt: "Flujograma: Leucocitosis con esplenomegalia"
  },
  "INF-030": {
    titulo: "Vectores de enfermedades en el Perú",
    imagen: "flujogramas/vectores-peru-chagas-triatoma.svg",
    alt: "Flujograma: Vectores de enfermedades en el Perú"
  },
  "GIN-069": {
    titulo: "Tipos de aborto",
    imagen: "flujogramas/aborto-terapeutico-lupus-nefropatia.svg",
    alt: "Flujograma: Tipos de aborto"
  },
  "INF-031": {
    titulo: "Malaria: especies de Plasmodium",
    imagen: "flujogramas/plasmodium-especies-falciparum-grave.svg",
    alt: "Flujograma: Malaria: especies de Plasmodium"
  },
  "PED-081": {
    titulo: "Niño nefrótico con fiebre y dolor abdominal",
    imagen: "flujogramas/nefrotico-nino-dolor-abdominal-peritonitis-primaria.svg",
    alt: "Flujograma: Niño nefrótico con fiebre y dolor abdominal"
  },
  "GIN-070": {
    titulo: "Sangrado indoloro en el tercer trimestre",
    imagen: "flujogramas/sangrado-indoloro-tercer-trimestre-placenta-previa.svg",
    alt: "Flujograma: Sangrado indoloro en el tercer trimestre"
  },
  "GIN-071": {
    titulo: "Síndromes de cáncer hereditario",
    imagen: "flujogramas/cancer-hereditario-brca1-mama.svg",
    alt: "Flujograma: Síndromes de cáncer hereditario"
  },
  "PED-082": {
    titulo: "Anemia en el lactante: el frotis",
    imagen: "flujogramas/lactante-prematuro-anemia-ferropenica.svg",
    alt: "Flujograma: Anemia en el lactante: el frotis"
  },
  "CIR-048": {
    titulo: "Tumoración sacrococcígea supurada",
    imagen: "flujogramas/masa-sacra-supurada-quiste-pilonidal.svg",
    alt: "Flujograma: Tumoración sacrococcígea supurada"
  },
  "CB-024": {
    titulo: "Síndrome colinérgico",
    imagen: "flujogramas/sindrome-colinergico-carbamatos.svg",
    alt: "Flujograma: Síndrome colinérgico"
  },
  "END-018": {
    titulo: "Hipertrigliceridemia: niveles y riesgo",
    imagen: "flujogramas/hipertrigliceridemia-xantomas-eruptivos-pancreatitis.svg",
    alt: "Flujograma: Hipertrigliceridemia: niveles y riesgo"
  },
  "GAS-024": {
    titulo: "Ictericia obstructiva indolora",
    imagen: "flujogramas/ictericia-obstructiva-colangiocarcinoma.svg",
    alt: "Flujograma: Ictericia obstructiva indolora"
  },
  "PED-083": {
    titulo: "Bronquiolitis: gravedad y manejo",
    imagen: "flujogramas/bronquiolitis-gravedad-manejo.svg",
    alt: "Flujograma: Bronquiolitis: gravedad y manejo"
  },
  "PED-084": {
    titulo: "Distrés en el RN a término con meconio",
    imagen: "flujogramas/rn-termino-liquido-meconial-aspiracion.svg",
    alt: "Flujograma: Distrés en el RN a término con meconio"
  },
  "GAS-025": {
    titulo: "Hematemesis: causas",
    imagen: "flujogramas/hematemesis-vomitos-alcohol-mallory-weiss.svg",
    alt: "Flujograma: Hematemesis: causas"
  },
  "PED-085": {
    titulo: "Intoxicación por plaguicida en un niño",
    imagen: "flujogramas/nino-campo-fumigado-descontaminacion.svg",
    alt: "Flujograma: Intoxicación por plaguicida en un niño"
  },
  "GIN-072": {
    titulo: "Tamizaje de cáncer de cuello uterino",
    imagen: "flujogramas/papanicolaou-histerectomia-total-benigna.svg",
    alt: "Flujograma: Tamizaje de cáncer de cuello uterino"
  },
  "CIR-049": {
    titulo: "Masa femoral dolorosa e irreductible",
    imagen: "flujogramas/masa-femoral-irreductible-hernia-crural-estrangulada.svg",
    alt: "Flujograma: Masa femoral dolorosa e irreductible"
  },
  "NEU-022": {
    titulo: "Disnea súbita en el posoperatorio",
    imagen: "flujogramas/disnea-subita-postoperatorio-cadera-tep.svg",
    alt: "Flujograma: Disnea súbita en el posoperatorio"
  },
  "END-019": {
    titulo: "Nefropatía diabética: detección precoz",
    imagen: "flujogramas/nefropatia-diabetica-albuminuria-cociente.svg",
    alt: "Flujograma: Nefropatía diabética: detección precoz"
  },
  "PED-086": {
    titulo: "Niño contacto de tuberculosis",
    imagen: "flujogramas/contacto-tuberculosis-nino-terapia-preventiva.svg",
    alt: "Flujograma: Niño contacto de tuberculosis"
  },
  "SP-050": {
    titulo: "Faltas a la integridad en investigación",
    imagen: "flujogramas/integridad-investigacion-conflicto-intereses.svg",
    alt: "Flujograma: Faltas a la integridad en investigación"
  },
  "INF-032": {
    titulo: "LCR turbio con neutrófilos",
    imagen: "flujogramas/lcr-turbio-neutrofilos-meningitis-bacteriana.svg",
    alt: "Flujograma: LCR turbio con neutrófilos"
  },
  "SP-051": {
    titulo: "Factores de riesgo de la diabetes tipo 2",
    imagen: "flujogramas/promocion-salud-diabetes-sedentarismo.svg",
    alt: "Flujograma: Factores de riesgo de la diabetes tipo 2"
  },
  "INF-033": {
    titulo: "Lesiones cerebrales en el paciente con VIH",
    imagen: "flujogramas/vih-lesiones-cerebrales-toxoplasmosis.svg",
    alt: "Flujograma: Lesiones cerebrales en el paciente con VIH"
  },
  "GIN-073": {
    titulo: "Enfermedad inflamatoria pélvica: dónde tratar",
    imagen: "flujogramas/epi-falla-ambulatoria-hospitalizar.svg",
    alt: "Flujograma: Enfermedad inflamatoria pélvica: dónde tratar"
  },
  "PED-087": {
    titulo: "Lactante con polipnea y mala ganancia de peso",
    imagen: "flujogramas/lactante-sudoracion-hepatomegalia-icc.svg",
    alt: "Flujograma: Lactante con polipnea y mala ganancia de peso"
  },
  "INF-034": {
    titulo: "Diarrea parasitaria en el niño",
    imagen: "flujogramas/diarrea-grasosa-agua-cruda-giardia.svg",
    alt: "Flujograma: Diarrea parasitaria en el niño"
  },
  "PED-088": {
    titulo: "Neonato con tos y cianosis al lactar",
    imagen: "flujogramas/neonato-sonda-no-pasa-atresia-esofagica.svg",
    alt: "Flujograma: Neonato con tos y cianosis al lactar"
  },
  "INF-035": {
    titulo: "Recién nacido expuesto al VIH",
    imagen: "flujogramas/recien-nacido-expuesto-vih-zidovudina.svg",
    alt: "Flujograma: Recién nacido expuesto al VIH"
  },
  "CIR-050": {
    titulo: "Hemotórax: criterios de toracotomía",
    imagen: "flujogramas/hemotorax-drenaje-200-hora-toracotomia.svg",
    alt: "Flujograma: Hemotórax: criterios de toracotomía"
  },
  "CAR-030": {
    titulo: "Endocarditis infecciosa: signos",
    imagen: "flujogramas/fiebre-soplo-nuevo-roth-endocarditis.svg",
    alt: "Flujograma: Endocarditis infecciosa: signos"
  },
  "PED-089": {
    titulo: "Anemia ferropénica: qué debe comer",
    imagen: "flujogramas/anemia-ferropenica-nino-alimentos-hierro-hemo.svg",
    alt: "Flujograma: Anemia ferropénica: qué debe comer"
  },
  "OFT-017": {
    titulo: "Odinofagia con trismus",
    imagen: "flujogramas/odinofagia-trismus-absceso-periamigdalino-drenaje.svg",
    alt: "Flujograma: Odinofagia con trismus"
  },
  "GAS-026": {
    titulo: "HDA en el cirrótico: reanimación",
    imagen: "flujogramas/hematemesis-cirrotico-choque-cristaloides.svg",
    alt: "Flujograma: HDA en el cirrótico: reanimación"
  },
  "TRA-013": {
    titulo: "Cadera deformada tras un choque",
    imagen: "flujogramas/impacto-frontal-aduccion-rotacion-interna-luxacion-posterior-cadera.svg",
    alt: "Flujograma: Cadera deformada tras un choque"
  },
  "NEF-031": {
    titulo: "Lesión renal aguda: prerrenal o NTA",
    imagen: "flujogramas/oligoanuria-choque-hemorragico-necrosis-tubular-aguda.svg",
    alt: "Flujograma: Lesión renal aguda: prerrenal o NTA"
  },
  "INF-036": {
    titulo: "Úlcera genital: qué agente",
    imagen: "flujogramas/ulcera-genital-indolora-indurada-sifilis-primaria.svg",
    alt: "Flujograma: Úlcera genital: qué agente"
  },
  "GAS-027": {
    titulo: "Fiebre, ictericia y dolor biliar",
    imagen: "flujogramas/fiebre-ictericia-dolor-colangitis-charcot.svg",
    alt: "Flujograma: Fiebre, ictericia y dolor biliar"
  },
  "SP-052": {
    titulo: "Propiedades del agente infeccioso",
    imagen: "flujogramas/omicron-contagios-transmisibilidad-agente.svg",
    alt: "Flujograma: Propiedades del agente infeccioso"
  },
  "GAS-028": {
    titulo: "Pólipo de colon en la colonoscopia",
    imagen: "flujogramas/sangrado-rectal-polipo-pediculado-polipectomia.svg",
    alt: "Flujograma: Pólipo de colon en la colonoscopia"
  },
  "CAR-031": {
    titulo: "Hipertensión: consultorio frente a MAPA",
    imagen: "flujogramas/hipertension-bata-blanca-mapa.svg",
    alt: "Flujograma: Hipertensión: consultorio frente a MAPA"
  },
  "CAR-032": {
    titulo: "Edema facial y en esclavina",
    imagen: "flujogramas/edema-esclavina-sindrome-vena-cava-superior.svg",
    alt: "Flujograma: Edema facial y en esclavina"
  },
  "GIN-074": {
    titulo: "Masa anexial: qué es",
    imagen: "flujogramas/dolor-pelvico-masa-anexial-endometrioma.svg",
    alt: "Flujograma: Masa anexial: qué es"
  },
  "END-020": {
    titulo: "Amenorrea primaria con talla baja",
    imagen: "flujogramas/amenorrea-primaria-talla-baja-turner-cariotipo.svg",
    alt: "Flujograma: Amenorrea primaria con talla baja"
  },
  "PED-090": {
    titulo: "Intoxicación por paracetamol",
    imagen: "flujogramas/sobredosis-paracetamol-nino-acetilcisteina.svg",
    alt: "Flujograma: Intoxicación por paracetamol"
  },
  "GIN-075": {
    titulo: "Urocultivo con Lactobacillus en la gestante",
    imagen: "flujogramas/gestante-urocultivo-lactobacillus-repetir.svg",
    alt: "Flujograma: Urocultivo con Lactobacillus en la gestante"
  },
  "REU-022": {
    titulo: "Urticaria tras el ejercicio",
    imagen: "flujogramas/ronchas-ejercicio-ducha-caliente-urticaria-colinergica.svg",
    alt: "Flujograma: Urticaria tras el ejercicio"
  },
  "NRL-021": {
    titulo: "TEC: gravedad según Glasgow",
    imagen: "flujogramas/trauma-craneal-glasgow-12-tomografia.svg",
    alt: "Flujograma: TEC: gravedad según Glasgow"
  },
  "NEF-032": {
    titulo: "Hipermagnesemia por laxantes",
    imagen: "flujogramas/adulta-mayor-laxantes-salinos-hipermagnesemia.svg",
    alt: "Flujograma: Hipermagnesemia por laxantes"
  },
  "GIN-076": {
    titulo: "Imagen en la gestante con dolor en FID",
    imagen: "flujogramas/gestante-dolor-fid-apendicitis-ecografia.svg",
    alt: "Flujograma: Imagen en la gestante con dolor en FID"
  },
  "SP-053": {
    titulo: "Derechos de los usuarios de salud",
    imagen: "flujogramas/examen-unico-nacional-derecho-calidad-atencion.svg",
    alt: "Flujograma: Derechos de los usuarios de salud"
  },
  "CB-025": {
    titulo: "Genes de las dislipidemias",
    imagen: "flujogramas/hipercolesterolemia-familiar-xantomas-receptor-ldl.svg",
    alt: "Flujograma: Genes de las dislipidemias"
  },
  "PED-091": {
    titulo: "Estenosis pilórica: el trastorno ácido-base",
    imagen: "flujogramas/vomitos-proyectil-lactante-alcalosis-hipocloremica.svg",
    alt: "Flujograma: Estenosis pilórica: el trastorno ácido-base"
  },
  "CIR-051": {
    titulo: "Obstrucción intestinal: delgado o colon",
    imagen: "flujogramas/laparotomia-previa-obstruccion-intestinal-bridas.svg",
    alt: "Flujograma: Obstrucción intestinal: delgado o colon"
  },
  "CAR-033": {
    titulo: "Derrame pericárdico: cuándo drenar",
    imagen: "flujogramas/lupus-pulso-paradojico-taponamiento-pericardiocentesis.svg",
    alt: "Flujograma: Derrame pericárdico: cuándo drenar"
  },
  "REU-023": {
    titulo: "Manchas hipocrómicas en el tronco",
    imagen: "flujogramas/manchas-hipocromicas-tronco-pitiriasis-versicolor.svg",
    alt: "Flujograma: Manchas hipocrómicas en el tronco"
  },
  "SP-054": {
    titulo: "Principios de la bioética",
    imagen: "flujogramas/farmacos-sin-evidencia-pandemia-no-maleficencia.svg",
    alt: "Flujograma: Principios de la bioética"
  },
  "CAR-034": {
    titulo: "Trauma torácico cerrado con arritmia",
    imagen: "flujogramas/trauma-precordial-arritmia-contusion-miocardica-ecg.svg",
    alt: "Flujograma: Trauma torácico cerrado con arritmia"
  },
  "TRA-014": {
    titulo: "Manguito de los rotadores",
    imagen: "flujogramas/hombro-abduccion-dolorosa-supraespinoso.svg",
    alt: "Flujograma: Manguito de los rotadores"
  },
  "GIN-077": {
    titulo: "Presentación de cara",
    imagen: "flujogramas/presentacion-cara-mentoposterior-cesarea.svg",
    alt: "Flujograma: Presentación de cara"
  },
  "GIN-078": {
    titulo: "Datación del embarazo",
    imagen: "flujogramas/primer-control-edad-gestacional-ecografia-lcn.svg",
    alt: "Flujograma: Datación del embarazo"
  },
  "GAS-029": {
    titulo: "Hepatitis viral aguda: fases",
    imagen: "flujogramas/prodromo-ictericia-hepatitis-viral-aguda.svg",
    alt: "Flujograma: Hepatitis viral aguda: fases"
  },
  "GIN-079": {
    titulo: "Preeclampsia: criterios de severidad",
    imagen: "flujogramas/preeclampsia-severa-36-semanas-sulfato-magnesio.svg",
    alt: "Flujograma: Preeclampsia: criterios de severidad"
  },
  "INF-037": {
    titulo: "Clasificación del dengue",
    imagen: "flujogramas/fiebre-dolor-abdominal-vomitos-dengue-signos-alarma.svg",
    alt: "Flujograma: Clasificación del dengue"
  }
};
